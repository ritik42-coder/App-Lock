# App Lock Best

Pure native Android app locker (Kotlin + Jetpack Compose). Intruder selfie, PIN/pattern/biometric,
8 live & static lock-screen styles, cinematic intro, separate Light/Dark designs.

## Get the APK with GitHub (no Android Studio)

**Option A — upload the ZIP as-is**
1. Create a new GitHub repo.
2. In the repo: *Add file → Create new file*, name it `.github/workflows/build-apk.yml`
   and paste the contents of `build-apk.yml` (included next to this zip). Commit.
3. *Add file → Upload files* → drop `AppLockBest.zip` itself. Commit.
4. Open the **Actions** tab. The build runs (~6-10 min). The workflow unzips the project automatically.
5. Download `AppLockBest.apk` from the run's **Artifacts** or from **Releases** (easy on a phone).

**Option B — upload extracted files**
Extract the ZIP, drag everything (including the `.github` folder) into the repo, commit. Same build.

## On the phone
Install the APK, open it, create a PIN/pattern, then grant: Usage access, Display over other apps
(required), Camera, Notifications, Unrestricted battery (recommended). On Xiaomi/Oppo/Vivo/Samsung also
allow Auto-start and lock the app in Recents.

Note: Android 12+ shows a green camera dot while the camera is active; this cannot be hidden.
