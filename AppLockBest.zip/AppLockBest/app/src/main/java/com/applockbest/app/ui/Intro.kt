package com.applockbest.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.first
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.random.Random

private fun seg(t: Float, a: Float, b: Float) = ((t - a) / (b - a)).coerceIn(0f, 1f)
private fun eo(x: Float) = 1f - (1f - x).pow(3)
private fun eio(x: Float) = if (x < 0.5f) 4f * x * x * x else 1f - (-2f * x + 2f).pow(3) / 2f
private fun eob(x: Float): Float {
    val c1 = 1.70158f
    val c3 = c1 + 1f
    return 1f + c3 * (x - 1f).pow(3) + c1 * (x - 1f).pow(2)
}

private const val TITLE = "APP LOCK BEST"

@Composable
fun IntroScreen(onFinish: () -> Unit) {
    val prog = remember { Animatable(0f) }
    val haptic = LocalHapticFeedback.current
    var called by remember { mutableStateOf(false) }
    fun fin() {
        if (!called) {
            called = true
            onFinish()
        }
    }
    LaunchedEffect(Unit) {
        prog.animateTo(1f, tween(7200, easing = LinearEasing))
        fin()
    }
    LaunchedEffect(Unit) {
        snapshotFlow { prog.value >= 0.79f }.first { it }
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
    }
    val stars = remember {
        val r = Random(7)
        List(110) { floatArrayOf(r.nextFloat() * 6.283f, r.nextFloat(), 0.4f + r.nextFloat()) }
    }
    val cols = remember {
        listOf(
            0xFFFF6B6B, 0xFFFFB84D, 0xFF4DD0E1, 0xFF7C5CFF, 0xFF34D399, 0xFFFF7AB6,
            0xFF60A5FA, 0xFFFACC15, 0xFFA78BFA, 0xFF2DD4BF, 0xFFF97316, 0xFF22D3EE
        ).map { Color(it) }
    }
    Box(Modifier.fillMaxSize()) {
        Canvas(Modifier.fillMaxSize()) { drawIntro(prog.value, stars, cols) }
        Column(
            Modifier.fillMaxSize().padding(bottom = 150.dp),
            verticalArrangement = androidx.compose.foundation.layout.Arrangement.Bottom,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row {
                TITLE.forEachIndexed { i, ch ->
                    Text(
                        ch.toString(),
                        modifier = Modifier.graphicsLayer {
                            val p = eo(seg(prog.value, 0.82f + i * 0.007f, 0.91f + i * 0.007f))
                            alpha = p
                            translationY = (1f - p) * 46f
                            scaleX = 0.6f + 0.4f * p
                            scaleY = scaleX
                        },
                        style = TextStyle(
                            color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Black,
                            letterSpacing = 2.sp,
                            shadow = Shadow(Color(0xFF8B6CFF), Offset.Zero, 30f)
                        )
                    )
                }
            }
            Text(
                "YOUR APPS  •  FULLY SECURED",
                modifier = Modifier.padding(top = 10.dp).graphicsLayer { alpha = eo(seg(prog.value, 0.92f, 1f)) },
                style = TextStyle(color = Color(0xFFB7C0FF), fontSize = 12.sp, letterSpacing = 4.sp, fontWeight = FontWeight.Medium)
            )
        }
        Text(
            "Skip  ›",
            modifier = Modifier
                .align(Alignment.TopEnd)
                .systemBarsPadding()
                .padding(16.dp)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { fin() },
            style = TextStyle(color = Color(0x99FFFFFF), fontSize = 13.sp)
        )
    }
}

private fun DrawScope.drawIntro(t: Float, stars: List<FloatArray>, cols: List<Color>) {
    val w = size.width
    val h = size.height
    val cx = w / 2f
    val cy = h * 0.44f
    drawRect(Brush.verticalGradient(listOf(Color(0xFF03040C), Color(0xFF0A0E2A), Color(0xFF1A0B42))))
    val glow = 0.22f + 0.22f * eo(seg(t, 0f, 0.5f))
    drawCircle(
        Brush.radialGradient(listOf(Color(0xFF7C5CFF).copy(alpha = glow), Color.Transparent), Offset(cx, cy), w * 0.9f),
        w * 0.9f, Offset(cx, cy)
    )

    // warp-speed starfield
    val maxR = hypot(w, h) / 2f
    val streak = 0.03f + 0.22f * (1f - seg(t, 0.05f, 0.35f))
    for (s in stars) {
        val d = (s[1] + t * s[2] * 1.6f) % 1f
        val d0 = (d - streak * s[2] * 0.4f).coerceAtLeast(0f)
        val dx = cos(s[0])
        val dy = sin(s[0])
        val a = ((0.15f + 0.85f * d) * (1f - 0.6f * seg(t, 0.6f, 0.8f))).coerceIn(0f, 1f)
        drawLine(
            Color.White.copy(alpha = a),
            Offset(cx + dx * d0 * maxR, cy + dy * d0 * maxR),
            Offset(cx + dx * d * maxR, cy + dy * d * maxR),
            strokeWidth = 1.2f + 2.2f * d, cap = StrokeCap.Round
        )
    }

    // phone scene
    val phoneOut = seg(t, 0.58f, 0.72f)
    val pa = 1f - phoneOut
    if (pa > 0f) {
        val ph = min(h * 0.56f, w * 1.0f)
        val pw = ph * 0.5f
        scale(1f + 0.35f * eio(phoneOut), Offset(cx, cy)) {
            val left = cx - pw / 2f
            val top = cy - ph / 2f
            val corner = CornerRadius(pw * 0.16f)
            val path = Path().apply { addRoundRect(RoundRect(left, top, left + pw, top + ph, corner)) }
            val drawn = eo(seg(t, 0.08f, 0.26f))
            val fillA = seg(t, 0.22f, 0.32f)
            drawRoundRect(Color(0xFF0B1030).copy(alpha = 0.85f * fillA * pa), Offset(left, top), Size(pw, ph), corner)
            val pm = PathMeasure()
            pm.setPath(path, false)
            val part = Path()
            pm.getSegment(0f, pm.length * drawn, part, true)
            drawPath(part, Color(0xFF22D3EE).copy(alpha = 0.25f * pa), style = Stroke(width = 16f, cap = StrokeCap.Round))
            drawPath(
                part,
                Brush.linearGradient(listOf(Color(0xFF7C5CFF), Color(0xFF22D3EE)), Offset(left, top), Offset(left + pw, top + ph)),
                alpha = pa, style = Stroke(width = 5f, cap = StrokeCap.Round)
            )
            drawRoundRect(
                Color.White.copy(alpha = 0.5f * fillA * pa),
                Offset(cx - pw * 0.12f, top + ph * 0.03f), Size(pw * 0.24f, ph * 0.014f), CornerRadius(8f)
            )
            val cell = pw * 0.24f
            val gapX = (pw * 0.84f - cell * 3f) / 2f
            val gapY = (ph * 0.62f - cell * 4f) / 3f
            val gx = left + pw * 0.08f
            val gy = top + ph * 0.14f
            val scanY = gy - cell + (ph * 0.62f + cell * 1.2f) * seg(t, 0.40f, 0.60f)
            for (i in 0 until 12) {
                val r = i / 3
                val c = i % 3
                val x = gx + c * (cell + gapX)
                val y = gy + r * (cell + gapY)
                val st = 0.20f + i * 0.011f
                val pop = eob(seg(t, st, st + 0.07f))
                val lockAmt = ((scanY - (y + cell / 2f)) / (cell * 0.8f)).coerceIn(0f, 1f)
                val s = cell * pop
                val ctr = Offset(x + cell / 2f, y + cell / 2f)
                val col = lerp(cols[i], Color(0xFF3B2A8F), lockAmt * 0.85f)
                drawRoundRect(col.copy(alpha = pa), Offset(ctr.x - s / 2f, ctr.y - s / 2f), Size(s, s), CornerRadius(s * 0.28f))
                if (lockAmt > 0.05f) {
                    val g = s * 0.36f * lockAmt
                    val wc = Color.White.copy(alpha = pa * lockAmt)
                    drawRoundRect(wc, Offset(ctr.x - g / 2f, ctr.y - g * 0.1f), Size(g, g * 0.8f), CornerRadius(g * 0.15f))
                    drawArc(
                        color = wc, startAngle = 180f, sweepAngle = 180f, useCenter = false,
                        topLeft = Offset(ctr.x - g * 0.3f, ctr.y - g * 0.1f - g * 0.3f),
                        size = Size(g * 0.6f, g * 0.6f), style = Stroke(g * 0.14f)
                    )
                }
            }
            if (t > 0.40f && t < 0.60f) {
                drawRect(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, Color(0xFF22D3EE).copy(alpha = 0.5f), Color.Transparent),
                        startY = scanY - 40f, endY = scanY + 40f
                    ),
                    Offset(left, scanY - 40f), Size(pw, 80f)
                )
                drawLine(Color.White.copy(alpha = 0.9f), Offset(left + pw * 0.05f, scanY), Offset(left + pw * 0.95f, scanY), 3f)
            }
        }
    }

    // giant padlock
    val lockIn = seg(t, 0.60f, 0.70f)
    if (lockIn > 0f) {
        val l = min(w, h) * 0.36f
        val lift = -h * 0.07f * eio(seg(t, 0.84f, 0.95f))
        val shake = if (t in 0.79f..0.87f) sin(t * 600f) * 14f * (1f - seg(t, 0.79f, 0.87f)) else 0f
        val lcx = cx + shake
        val lcy = cy + lift
        scale(eob(lockIn), Offset(lcx, lcy)) {
            drawCircle(
                Brush.radialGradient(listOf(Color(0xFF7C5CFF).copy(alpha = 0.55f * lockIn), Color.Transparent), Offset(lcx, lcy), l * 1.3f),
                l * 1.3f, Offset(lcx, lcy)
            )
            val bodyW = l
            val bodyH = l * 0.8f
            val bodyTop = lcy - l * 0.05f
            val bodyLeft = lcx - bodyW / 2f
            val openAmt = if (t < 0.76f) eo(seg(t, 0.66f, 0.74f)) else 1f - seg(t, 0.76f, 0.79f).pow(3)
            val r = bodyW * 0.30f
            val dy = -l * 0.34f * openAmt
            val acy = bodyTop - l * 0.2f + dy
            val sh = Path().apply {
                moveTo(lcx - r, bodyTop + dy)
                lineTo(lcx - r, acy)
                arcTo(Rect(lcx - r, acy - r, lcx + r, acy + r), 180f, 180f, false)
                lineTo(lcx + r, bodyTop + dy)
            }
            drawPath(
                sh, Brush.linearGradient(listOf(Color(0xFFF1EEFF), Color(0xFF9F8CFF)), Offset(lcx - r, acy - r), Offset(lcx + r, bodyTop)),
                style = Stroke(width = l * 0.11f, cap = StrokeCap.Round)
            )
            drawRoundRect(
                Brush.verticalGradient(listOf(Color(0xFF8B6CFF), Color(0xFF4A2BD6)), startY = bodyTop, endY = bodyTop + bodyH),
                Offset(bodyLeft, bodyTop), Size(bodyW, bodyH), CornerRadius(l * 0.16f)
            )
            drawRoundRect(Color.White.copy(alpha = 0.25f), Offset(bodyLeft + l * 0.06f, bodyTop + l * 0.05f), Size(bodyW - l * 0.12f, l * 0.05f), CornerRadius(l * 0.03f))
            val kc = Offset(lcx, bodyTop + bodyH * 0.42f)
            drawCircle(Color.White, l * 0.09f, kc)
            drawRoundRect(Color.White, Offset(kc.x - l * 0.025f, kc.y), Size(l * 0.05f, l * 0.16f), CornerRadius(l * 0.02f))
        }
    }

    // shockwave + flash on lock-in
    if (t > 0.79f) {
        val p = seg(t, 0.79f, 0.95f)
        drawCircle(Color(0xFF22D3EE).copy(alpha = (1f - p) * 0.8f), eo(p) * maxR * 0.9f, Offset(cx, cy), style = Stroke(10f * (1f - p) + 2f))
        val p2 = seg(t, 0.81f, 0.97f)
        drawCircle(Color(0xFF7C5CFF).copy(alpha = (1f - p2) * 0.7f), eo(p2) * maxR * 0.8f, Offset(cx, cy), style = Stroke(8f * (1f - p2) + 2f))
        val flash = 1f - seg(t, 0.79f, 0.85f)
        drawRect(Color.White.copy(alpha = flash * 0.55f))
    }
}
