package com.applockbest.app.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.applockbest.app.MainActivity
import com.applockbest.app.data.Cred
import com.applockbest.app.data.Perms
import com.applockbest.app.data.Store
import com.applockbest.app.service.LockService
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun rememberResumeTick(): Int {
    var t by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) t++ }
        owner.lifecycle.addObserver(o)
        onDispose { owner.lifecycle.removeObserver(o) }
    }
    return t
}

private fun safeStart(act: MainActivity, i: Intent) {
    try {
        act.startActivity(i)
    } catch (e: Exception) {
        try {
            act.startActivity(Intent(Settings.ACTION_SETTINGS))
        } catch (e2: Exception) {
        }
    }
}

@Composable
private fun PermRow(title: String, desc: String, granted: Boolean, required: Boolean, onGrant: () -> Unit) {
    val pal = LocalPal.current
    GlassCard(Modifier.fillMaxWidth(), radius = 18.dp) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(38.dp).border(1.dp, if (granted) pal.good else pal.bad, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (granted) Icons.Rounded.Check else Icons.Rounded.Warning, null,
                    tint = if (granted) pal.good else pal.bad, modifier = Modifier.size(20.dp)
                )
            }
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                ALText(title + if (required) "  •  required" else "", size = 14, weight = FontWeight.SemiBold)
                ALText(desc, size = 12, color = pal.sub)
            }
            if (!granted) {
                Box(
                    Modifier.bounceClick(onGrant)
                        .background(pal.accent, RoundedCornerShape(12.dp))
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) { ALText("Grant", size = 12, weight = FontWeight.Bold, color = Color.White) }
            }
        }
    }
}

@Composable
fun PermissionsPanel(act: MainActivity) {
    val ctx = LocalContext.current
    val tick = rememberResumeTick()
    var flip by remember { mutableIntStateOf(0) }
    val camL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        flip++
        act.cam.prepare()
    }
    val notL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { flip++ }
    val u = remember(tick, flip) { Perms.usage(ctx) }
    val o = remember(tick, flip) { Perms.overlay(ctx) }
    val c = remember(tick, flip) { Perms.camera(ctx) }
    val n = remember(tick, flip) { Perms.notif(ctx) }
    val b = remember(tick, flip) { Perms.battery(ctx) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        PermRow("Usage access", "Detects which app you open so it can be locked.", u, true) {
            safeStart(act, Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        PermRow("Display over other apps", "Shows the lock screen on top of locked apps.", o, true) {
            safeStart(act, Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
        }
        PermRow("Camera", "Takes the intruder selfie after wrong attempts.", c, false) {
            camL.launch(Manifest.permission.CAMERA)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            PermRow("Notifications", "Alerts you when an intruder is caught.", n, false) {
                notL.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        PermRow("Unrestricted battery", "Keeps the lock alive in the background.", b, false) {
            safeStart(act, Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}")))
        }
    }
}

@Composable
private fun OptionCard(title: String, desc: String, selected: Boolean, onClick: () -> Unit) {
    val pal = LocalPal.current
    GlassCard(
        Modifier.fillMaxWidth().bounceClick(onClick)
            .border(2.dp, if (selected) pal.accent else Color.Transparent, RoundedCornerShape(24.dp)),
    ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                ALText(title, size = 16, weight = FontWeight.Bold)
                ALText(desc, size = 12, color = pal.sub)
            }
            if (selected) Icon(Icons.Rounded.Check, null, tint = pal.accent)
        }
    }
}

/** Create + confirm a PIN (4/6) or pattern. onDone(type, pinLength, code). */
@Composable
fun CredentialCreator(onDone: (String, Int, String) -> Unit, onCancel: (() -> Unit)? = null, lockKind: Int? = null) {
    val pal = LocalPal.current
    var kind by remember { mutableIntStateOf(lockKind ?: 0) }
    var step by remember { mutableIntStateOf(if (lockKind != null) 1 else 0) }
    var first by remember { mutableStateOf("") }
    var input by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var err by remember { mutableStateOf(false) }
    val shake = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val len = if (kind == 1) 6 else 4

    fun mismatch() {
        err = true
        msg = "Didn't match — start again"
        scope.launch {
            for (v in listOf(-24f, 24f, -16f, 16f, -8f, 8f, 0f)) shake.animateTo(v, tween(45))
            delay(250)
            err = false
            input = ""
            first = ""
            step = 1
        }
    }

    fun submit(code: String) {
        if (step == 1) {
            first = code
            input = ""
            step = 2
            msg = ""
        } else if (code == first) {
            onDone(if (kind == 2) "PATTERN" else "PIN", len, code)
        } else {
            mismatch()
        }
    }

    Column(
        Modifier.fillMaxSize().padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ALText(
            when (step) {
                0 -> "Choose your lock"
                1 -> if (kind == 2) "Draw a new pattern" else "Create your PIN"
                else -> if (kind == 2) "Draw it again" else "Confirm your PIN"
            },
            size = 24, weight = FontWeight.Black
        )
        Spacer(Modifier.height(6.dp))
        ALText(
            if (msg.isNotEmpty()) msg else if (step == 0) "You can change this any time in Settings." else "Connect at least 4 dots / enter all digits",
            size = 13, color = if (err) pal.bad else pal.sub, align = TextAlign.Center
        )
        Spacer(Modifier.height(18.dp))
        if (step == 0) {
            Column(Modifier.widthIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OptionCard("4-digit PIN", "Fast and simple", kind == 0) { kind = 0 }
                OptionCard("6-digit PIN", "Stronger numeric code", kind == 1) { kind = 1 }
                OptionCard("Pattern", "Draw a path across 9 dots", kind == 2) { kind = 2 }
            }
            Spacer(Modifier.weight(1f))
            GradientButton("Continue", Modifier.fillMaxWidth().widthIn(max = 420.dp)) { step = 1 }
        } else if (kind == 2) {
            Spacer(Modifier.weight(1f))
            PatternPad(
                Modifier.widthIn(max = 300.dp).fillMaxWidth(0.85f),
                ink = pal.text, accent = pal.accent, hidePath = false, error = err
            ) { code ->
                if (!err) {
                    if (code.length < 4) {
                        msg = "Connect at least 4 dots"
                    } else submit(code)
                }
            }
            Spacer(Modifier.weight(1f))
        } else {
            Spacer(Modifier.weight(1f))
            PinDots(len, input.length, pal.text, err, shake.value)
            Spacer(Modifier.height(24.dp))
            PinPad(pal.text, false, 0, !err, onDigit = { d ->
                if (input.length < len) {
                    input += d
                    if (input.length == len) {
                        val code = input
                        scope.launch {
                            delay(180)
                            submit(code)
                        }
                    }
                }
            }, onDelete = { if (input.isNotEmpty()) input = input.dropLast(1) }, onBiometric = null)
            Spacer(Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
            if (step > 0 && lockKind == null) {
                Box(Modifier.bounceClick { step = 0; input = ""; first = ""; msg = "" }.padding(8.dp)) {
                    ALText("Back", size = 14, color = pal.sub)
                }
            }
            if (onCancel != null) {
                Box(Modifier.bounceClick(onCancel).padding(8.dp)) { ALText("Cancel", size = 14, color = pal.sub) }
            }
        }
    }
}

@Composable
fun SetupFlow(act: MainActivity, onFinish: () -> Unit) {
    var step by rememberSaveable { mutableIntStateOf(0) }
    val pal = LocalPal.current
    val ctx = LocalContext.current
    Box(Modifier.fillMaxSize()) {
        LiveBackground()
        Column(Modifier.fillMaxSize().systemBarsPadding().padding(20.dp)) {
            AnimatedContent(
                step,
                modifier = Modifier.weight(1f),
                transitionSpec = {
                    (slideInHorizontally(tween(450)) { it / 3 } + fadeIn(tween(450))) togetherWith
                        (slideOutHorizontally(tween(300)) { -it / 3 } + fadeOut(tween(250)))
                },
                label = "setup"
            ) { s ->
                when (s) {
                    0 -> Column(
                        Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Spacer(Modifier.height(10.dp))
                        Box(contentAlignment = Alignment.Center) {
                            HeroOrb(true)
                            Icon(Icons.Rounded.Shield, null, tint = Color.White, modifier = Modifier.size(72.dp))
                        }
                        ALText("App Lock Best", size = 30, weight = FontWeight.Black)
                        ALText("Premium protection for every app you care about.", color = pal.sub, align = TextAlign.Center)
                        Spacer(Modifier.height(16.dp))
                        Column(Modifier.widthIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            for (f in listOf(
                                "Lock any app with PIN, pattern or biometrics",
                                "Intruder selfie after wrong attempts",
                                "8 live & static lock-screen styles",
                                "Separate Light and Dark designs"
                            )) {
                                GlassCard(Modifier.fillMaxWidth(), radius = 16.dp) {
                                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Rounded.Lock, null, tint = pal.accent, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.size(10.dp))
                                        ALText(f, size = 14)
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(24.dp))
                        GradientButton("Get started", Modifier.fillMaxWidth().widthIn(max = 420.dp)) { step = 1 }
                    }

                    1 -> CredentialCreator(onDone = { type, len, code ->
                        Cred.set(type, len, code)
                        step = 2
                    })

                    else -> Column(
                        Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        ALText("Almost there", size = 26, weight = FontWeight.Black)
                        ALText(
                            "Grant the two required permissions so locking can work. The rest make it smarter.",
                            color = pal.sub, align = TextAlign.Center
                        )
                        Spacer(Modifier.height(16.dp))
                        PermissionsPanel(act)
                        Spacer(Modifier.height(18.dp))
                        GradientButton("Start protecting", Modifier.fillMaxWidth(), Icons.Rounded.LockOpen) {
                            if (Perms.coreReady(ctx)) {
                                Store.update { serviceOn = true }
                                LockService.start(ctx)
                            }
                            onFinish()
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                }
            }
        }
    }
}
