package com.applockbest.app.data

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import org.json.JSONObject
import java.io.DataInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** AES-256-GCM encrypted file vault. The key lives in the Android Keystore and never leaves it. */
object Vault {
    private const val ALIAS = "alb_vault_key"

    data class Item(val id: String, val name: String, val mime: String, val size: Long, val time: Long, val file: File)

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore")
        ks.load(null)
        val existing = ks.getKey(ALIAS, null)
        if (existing is SecretKey) return existing
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return kg.generateKey()
    }

    fun dir(c: Context): File = File(c.filesDir, "vault").also { it.mkdirs() }

    fun list(c: Context): List<Item> {
        val out = ArrayList<Item>()
        val files = dir(c).listFiles() ?: return out
        for (f in files) {
            if (!f.name.endsWith(".json")) continue
            try {
                val id = f.name.removeSuffix(".json")
                val j = JSONObject(f.readText())
                val enc = File(dir(c), "$id.enc")
                if (enc.exists()) {
                    out.add(Item(id, j.optString("n", "file"), j.optString("m", "application/octet-stream"), j.optLong("s"), j.optLong("t"), enc))
                }
            } catch (e: Exception) {
            }
        }
        return out.sortedByDescending { it.time }
    }

    private fun encryptTo(input: InputStream, out: File): Long {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val iv = cipher.iv
        var n = 0L
        FileOutputStream(out).use { fos ->
            fos.write(iv.size)
            fos.write(iv)
            CipherOutputStream(fos, cipher).use { cos ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val r = input.read(buf)
                    if (r < 0) break
                    cos.write(buf, 0, r)
                    n += r
                }
            }
        }
        return n
    }

    fun add(c: Context, uri: Uri): Boolean {
        return try {
            val cr = c.contentResolver
            var name = "file"
            cr.query(uri, null, null, null, null)?.use { cur ->
                val i = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && cur.moveToFirst()) name = cur.getString(i) ?: name
            }
            val mime = cr.getType(uri) ?: "application/octet-stream"
            val id = System.currentTimeMillis().toString() + (100..999).random()
            val enc = File(dir(c), "$id.enc")
            val input = cr.openInputStream(uri) ?: return false
            val size = input.use { encryptTo(it, enc) }
            if (!enc.exists() || enc.length() == 0L) return false
            File(dir(c), "$id.json").writeText(
                JSONObject().put("n", name).put("m", mime).put("s", size).put("t", System.currentTimeMillis()).toString()
            )
            true
        } catch (e: Exception) {
            false
        }
    }

    fun open(item: Item): InputStream {
        val fis = FileInputStream(item.file)
        val ivLen = fis.read()
        val iv = ByteArray(ivLen)
        DataInputStream(fis).readFully(iv)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
        return CipherInputStream(fis, cipher)
    }

    fun image(item: Item, sample: Int): ImageBitmap? {
        if (item.size > 40L * 1024 * 1024) return null
        return try {
            val bytes = open(item).use { it.readBytes() }
            val o = BitmapFactory.Options()
            o.inSampleSize = sample
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)?.asImageBitmap()
        } catch (e: Exception) {
            null
        }
    }

    fun export(c: Context, item: Item, uri: Uri): Boolean {
        return try {
            val out = c.contentResolver.openOutputStream(uri) ?: return false
            out.use { o -> open(item).use { it.copyTo(o) } }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun delete(c: Context, item: Item) {
        item.file.delete()
        File(dir(c), item.id + ".json").delete()
        Store.vaultTick = Store.vaultTick + 1
    }
}
