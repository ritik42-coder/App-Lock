package com.applockbest.app.service

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.applockbest.app.MainActivity
import com.applockbest.app.R
import com.applockbest.app.data.Perms
import com.applockbest.app.data.Store

/** Home-screen tile. Tap while OFF = start protection. Tap while ON = open the app (needs your unlock). */
class LockWidget : AppWidgetProvider() {

    companion object {
        const val ACTION = "com.applockbest.app.WIDGET_START"

        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, LockWidget::class.java))
            for (id in ids) m.updateAppWidget(id, views(c))
        }

        private fun views(c: Context): RemoteViews {
            Store.init(c)
            val v = RemoteViews(c.packageName, R.layout.widget_lock)
            val on = Store.serviceOn && Perms.coreReady(c)
            v.setTextViewText(R.id.widget_state, if (on) "ON - tap to open" else "OFF - tap to start")
            val pi = if (on) {
                PendingIntent.getActivity(c, 6, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            } else {
                PendingIntent.getBroadcast(
                    c, 5, Intent(c, LockWidget::class.java).setAction(ACTION),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            }
            v.setOnClickPendingIntent(R.id.widget_root, pi)
            return v
        }
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) manager.updateAppWidget(id, views(context))
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION) {
            Store.init(context)
            if (!Store.serviceOn && Perms.coreReady(context)) {
                try {
                    LockService.start(context)
                    Store.update { serviceOn = true }
                } catch (e: Exception) {
                }
            }
            refresh(context)
        }
    }
}
