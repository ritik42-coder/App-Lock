package com.applockbest.app.camera

import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.view.Surface
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.applockbest.app.data.Intruders
import com.applockbest.app.data.Perms
import com.applockbest.app.data.Store

/** Silent front-camera capture, bound to the host activity lifecycle. */
class IntruderCam(private val act: FragmentActivity) {
    private var capture: ImageCapture? = null
    private var provider: ProcessCameraProvider? = null
    private var pending: String? = null

    fun prepare() {
        if (!Store.intruderOn || !Perms.camera(act) || capture != null) return
        val fut = ProcessCameraProvider.getInstance(act)
        val exec = ContextCompat.getMainExecutor(act)
        fut.addListener({
            try {
                val p = fut.get()
                val ic = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .build()
                val pv = Preview.Builder().build()
                // Hidden dummy surface so capture works reliably on every phone.
                pv.setSurfaceProvider(exec) { req ->
                    val st = SurfaceTexture(0)
                    st.setDefaultBufferSize(req.resolution.width, req.resolution.height)
                    val s = Surface(st)
                    req.provideSurface(s, exec) {
                        s.release()
                        st.release()
                    }
                }
                p.unbindAll()
                p.bindToLifecycle(act, CameraSelector.DEFAULT_FRONT_CAMERA, pv, ic)
                provider = p
                capture = ic
                val t = pending
                if (t != null) {
                    pending = null
                    snap(t)
                }
            } catch (e: Exception) {
            }
        }, exec)
    }

    fun snap(target: String) {
        val ic = capture
        if (ic == null) {
            pending = target
            prepare()
            return
        }
        ic.takePicture(ContextCompat.getMainExecutor(act), object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    val bmp = image.toBitmap()
                    val m = Matrix()
                    m.postRotate(image.imageInfo.rotationDegrees.toFloat())
                    m.postScale(-1f, 1f)
                    var out = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                    val big = maxOf(out.width, out.height)
                    if (big > 1280) {
                        val f = 1280f / big
                        out = Bitmap.createScaledBitmap(out, (out.width * f).toInt(), (out.height * f).toInt(), true)
                    }
                    Intruders.save(act, out, target)
                } catch (e: Exception) {
                } finally {
                    image.close()
                }
            }

            override fun onError(exception: ImageCaptureException) {}
        })
    }

    fun release() {
        try {
            provider?.unbindAll()
        } catch (e: Exception) {
        }
        capture = null
    }
}

fun canBiometric(c: android.content.Context): Boolean =
    Store.biometric &&
        BiometricManager.from(c).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) ==
        BiometricManager.BIOMETRIC_SUCCESS

fun FragmentActivity.askBiometric(onOk: () -> Unit) {
    val exec = ContextCompat.getMainExecutor(this)
    val prompt = BiometricPrompt(this, exec, object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
            onOk()
        }
    })
    val info = BiometricPrompt.PromptInfo.Builder()
        .setTitle("App Lock Best")
        .setSubtitle("Unlock with biometrics")
        .setNegativeButtonText("Use PIN / pattern")
        .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
        .build()
    prompt.authenticate(info)
}
