package com.applockbest.app.service

import android.app.admin.DeviceAdminReceiver

/** Being an active device admin stops the app from being uninstalled until it is turned off. */
class AdminReceiver : DeviceAdminReceiver()
