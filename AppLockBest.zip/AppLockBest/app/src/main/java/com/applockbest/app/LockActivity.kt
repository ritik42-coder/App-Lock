package com.applockbest.app

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import androidx.fragment.app.FragmentActivity
import com.applockbest.app.camera.IntruderCam
import com.applockbest.app.camera.askBiometric
import com.applockbest.app.camera.canBiometric
import com.applockbest.app.data.Cred
import com.applockbest.app.data.Store
import com.applockbest.app.data.labelOf
import com.applockbest.app.service.LockService
import com.applockbest.app.ui.ALBTheme
import com.applockbest.app.ui.LocalPal
import com.applockbest.app.ui.LockScreen

/** Full-screen lock shown on top of a protected app. */
class LockActivity : FragmentActivity() {
    private var target by mutableStateOf<String?>(null)
    private var finished = false
    private val cam by lazy { IntruderCam(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        enableEdgeToEdge()
        Store.init(this)
        target = intent.getStringExtra("pkg")
        cam.prepare()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                goHome()
            }
        })
        setContent {
            ALBTheme {
                val pkg = target ?: packageName
                val dark = LocalPal.current.dark
                val bioFn: (() -> Unit) -> Unit = { cb -> askBiometric(cb) }
                val bio = if (canBiometric(this@LockActivity)) bioFn else null
                key(pkg) {
                    val label = remember(pkg) { labelOf(this@LockActivity, pkg) }
                    val icon = remember(pkg) {
                        try {
                            packageManager.getApplicationIcon(pkg).toBitmap(192, 192).asImageBitmap()
                        } catch (e: Exception) {
                            null
                        }
                    }
                    val cfg = Store.cfg(pkg)
                    val own = cfg.credHash.isNotEmpty()
                    LockScreen(
                        title = label,
                        subtitle = "Locked by App Lock Best",
                        icon = icon,
                        styleId = cfg.style.ifEmpty { Store.lockStyle },
                        dark = dark,
                        onSuccess = {
                            LockService.unlock(pkg)
                            finished = true
                            finish()
                        },
                        onWrong = { c -> if (Store.intruderOn && cfg.selfie && c % Store.intruderAttempts == 0) cam.snap(pkg) },
                        biometric = bio,
                        autoBiometric = true,
                        credType = if (own) cfg.credType else Store.credType,
                        pinLen = if (own) cfg.pinLen else Store.pinLen,
                        verify = { code -> Cred.verifyApp(pkg, code) },
                        message = cfg.msg,
                        unlockFx = Store.unlockFx
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        target = intent.getStringExtra("pkg")
    }

    private fun goHome() {
        startActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        finishAndRemoveTask()
    }

    override fun onStop() {
        super.onStop()
        if (!finished && !isChangingConfigurations) finishAndRemoveTask()
    }

    override fun onDestroy() {
        cam.release()
        super.onDestroy()
    }
}
