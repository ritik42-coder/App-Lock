package com.applockbest.app.service

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.applockbest.app.data.Intruders
import com.applockbest.app.data.Notifier
import com.applockbest.app.data.Store
import java.util.Calendar

object ReportScheduler {
    private fun pending(c: Context): PendingIntent = PendingIntent.getBroadcast(
        c, 77, Intent(c, ReportReceiver::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    /** (Re)schedules the next daily report. Safe to call any time. */
    fun schedule(c: Context) {
        Store.init(c)
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(c)
        am.cancel(pi)
        if (!Store.dailyOn) return
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, Store.dailyHour)
        cal.set(Calendar.MINUTE, Store.dailyMin)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (cal.timeInMillis <= System.currentTimeMillis() + 1000L) cal.add(Calendar.DAY_OF_YEAR, 1)
        try {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        } catch (e: Exception) {
        }
    }
}

/** Fires once a day at the chosen time. Notifies only when intruder photos exist. */
class ReportReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Store.init(c)
        try {
            if (Store.dailyOn) {
                val list = Intruders.list(c)
                if (list.isNotEmpty()) {
                    val weekAgo = System.currentTimeMillis() - 7L * 86_400_000L
                    Notifier.report(c, list.size, list.count { it.time >= weekAgo })
                }
            }
        } finally {
            ReportScheduler.schedule(c)
        }
    }
}
