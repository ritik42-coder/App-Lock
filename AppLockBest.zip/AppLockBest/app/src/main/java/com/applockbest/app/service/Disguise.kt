package com.applockbest.app.service

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

/** Switches the launcher icon + name between the real one and Calculator / Clock / Notes. */
object Disguise {
    private val aliases = listOf(".AliasDefault", ".AliasCalc", ".AliasClock", ".AliasNotes")

    fun apply(c: Context, idx: Int) {
        val pm = c.packageManager
        fun comp(i: Int) = ComponentName(c.packageName, "com.applockbest.app" + aliases[i])
        pm.setComponentEnabledSetting(comp(idx), PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
        for (i in aliases.indices) {
            if (i != idx) {
                pm.setComponentEnabledSetting(comp(i), PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
            }
        }
    }
}
