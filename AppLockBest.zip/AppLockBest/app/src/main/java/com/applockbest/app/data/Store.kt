package com.applockbest.app.data

import android.Manifest
import android.app.AppOpsManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.PowerManager
import android.os.Process
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.applockbest.app.MainActivity
import com.applockbest.app.R
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import org.json.JSONObject

data class AppCfg(
    val style: String = "",
    val msg: String = "",
    val selfie: Boolean = true,
    val credType: String = "",
    val pinLen: Int = 4,
    val credHash: String = ""
)

private fun encodeCfg(m: Map<String, AppCfg>): String {
    val o = JSONObject()
    for ((k, v) in m) {
        o.put(k, JSONObject().put("s", v.style).put("m", v.msg).put("i", v.selfie)
            .put("t", v.credType).put("l", v.pinLen).put("h", v.credHash))
    }
    return o.toString()
}

private fun decodeCfg(s: String): Map<String, AppCfg> {
    val out = HashMap<String, AppCfg>()
    try {
        val o = JSONObject(s)
        val keys = o.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val j = o.getJSONObject(k)
            out[k] = AppCfg(
                j.optString("s"), j.optString("m"), j.optBoolean("i", true),
                j.optString("t"), j.optInt("l", 4), j.optString("h")
            )
        }
    } catch (e: Exception) {
    }
    return out
}

object Store {
    private var sp: SharedPreferences? = null

    var lockedApps by mutableStateOf(setOf<String>())
    var credHash by mutableStateOf("")
    var credType by mutableStateOf("PIN")
    var pinLen by mutableStateOf(4)
    var serviceOn by mutableStateOf(false)
    var intruderOn by mutableStateOf(true)
    var intruderAttempts by mutableStateOf(2)
    var biometric by mutableStateOf(true)
    var shuffle by mutableStateOf(false)
    var haptics by mutableStateOf(true)
    var hidePath by mutableStateOf(false)
    var relock by mutableStateOf(0)          // 0 instantly, 1 after 1 min, 2 after screen off
    var lockStyle by mutableStateOf("aurora")
    var themeMode by mutableStateOf(0)       // 0 system, 1 light, 2 dark
    var intruderTick by mutableStateOf(0)
    var unlockFx by mutableStateOf(0)        // 0 check, 1 padlock, 2 portal
    var appCfg by mutableStateOf(mapOf<String, AppCfg>())

    fun init(c: Context) {
        if (sp != null) return
        val p = c.applicationContext.getSharedPreferences("alb_store", Context.MODE_PRIVATE)
        sp = p
        lockedApps = p.getStringSet("locked", emptySet())?.toSet() ?: emptySet()
        credHash = p.getString("hash", "") ?: ""
        credType = p.getString("type", "PIN") ?: "PIN"
        pinLen = p.getInt("pinLen", 4)
        serviceOn = p.getBoolean("svc", false)
        intruderOn = p.getBoolean("intr", true)
        intruderAttempts = p.getInt("attempts", 2)
        biometric = p.getBoolean("bio", true)
        shuffle = p.getBoolean("shuffle", false)
        haptics = p.getBoolean("haptics", true)
        hidePath = p.getBoolean("hidePath", false)
        relock = p.getInt("relock", 0)
        lockStyle = p.getString("style", "aurora") ?: "aurora"
        themeMode = p.getInt("theme", 0)
        unlockFx = p.getInt("fx", 0)
        appCfg = decodeCfg(p.getString("appcfg", "") ?: "")
    }

    fun save() {
        val e = sp?.edit() ?: return
        e.putStringSet("locked", lockedApps.toSet())
        e.putString("hash", credHash)
        e.putString("type", credType)
        e.putInt("pinLen", pinLen)
        e.putBoolean("svc", serviceOn)
        e.putBoolean("intr", intruderOn)
        e.putInt("attempts", intruderAttempts)
        e.putBoolean("bio", biometric)
        e.putBoolean("shuffle", shuffle)
        e.putBoolean("haptics", haptics)
        e.putBoolean("hidePath", hidePath)
        e.putInt("relock", relock)
        e.putString("style", lockStyle)
        e.putInt("theme", themeMode)
        e.putInt("fx", unlockFx)
        e.putString("appcfg", encodeCfg(appCfg))
        e.apply()
    }

    fun cfg(pkg: String): AppCfg = appCfg[pkg] ?: AppCfg()

    fun setCfg(pkg: String, c: AppCfg) {
        update { appCfg = if (c == AppCfg()) appCfg - pkg else appCfg + (pkg to c) }
    }

    fun update(block: Store.() -> Unit) {
        this.block()
        save()
    }
}

object Cred {
    fun hash(s: String): String =
        MessageDigest.getInstance("SHA-256").digest("alb\u0001$s".toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun set(type: String, len: Int, code: String) {
        Store.update {
            credType = type
            pinLen = len
            credHash = hash(code)
        }
    }

    fun verify(code: String): Boolean = Store.credHash.isNotEmpty() && hash(code) == Store.credHash

    /** Verifies against the app's own passcode if it has one, otherwise the global one. */
    fun verifyApp(pkg: String, code: String): Boolean {
        val c = Store.cfg(pkg)
        return if (c.credHash.isNotEmpty()) hash(code) == c.credHash else verify(code)
    }
}

object Perms {
    @Suppress("DEPRECATION")
    fun usage(c: Context): Boolean {
        val a = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29)
            a.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        else
            a.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun overlay(c: Context): Boolean = Settings.canDrawOverlays(c)

    fun camera(c: Context): Boolean =
        ContextCompat.checkSelfPermission(c, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    fun notif(c: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun battery(c: Context): Boolean {
        val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(c.packageName)
    }

    fun coreReady(c: Context): Boolean = usage(c) && overlay(c)
}

fun labelOf(c: Context, pkg: String): String {
    if (pkg == c.packageName) return "App Lock Best"
    return try {
        val pm = c.packageManager
        @Suppress("DEPRECATION")
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }
}

data class Intruder(val file: File, val time: Long, val pkg: String)

object Intruders {
    private const val SEP = "@@"

    fun dir(c: Context): File = File(c.filesDir, "intruders").also { it.mkdirs() }

    fun list(c: Context): List<Intruder> =
        dir(c).listFiles()?.mapNotNull { f ->
            val p = f.nameWithoutExtension.split(SEP)
            val t = p.getOrNull(0)?.toLongOrNull()
            if (t == null || p.size < 2) null else Intruder(f, t, p[1])
        }?.sortedByDescending { it.time } ?: emptyList()

    fun save(c: Context, bmp: Bitmap, pkg: String) {
        val f = File(dir(c), "${System.currentTimeMillis()}$SEP$pkg.jpg")
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 86, it) }
        Store.intruderTick = Store.intruderTick + 1
        Notifier.intruder(c, pkg)
    }

    fun delete(i: Intruder) {
        i.file.delete()
        Store.intruderTick = Store.intruderTick + 1
    }

    fun clear(c: Context) {
        dir(c).listFiles()?.forEach { it.delete() }
        Store.intruderTick = Store.intruderTick + 1
    }
}

object Notifier {
    const val CH_SERVICE = "alb_service"
    const val CH_ALERT = "alb_alert"

    fun channels(c: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CH_SERVICE, "Protection status", NotificationManager.IMPORTANCE_LOW)
            )
            nm.createNotificationChannel(
                NotificationChannel(CH_ALERT, "Intruder alerts", NotificationManager.IMPORTANCE_HIGH)
            )
        }
    }

    fun intruder(c: Context, pkg: String) {
        if (!Perms.notif(c)) return
        val pi = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(c, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat_lock)
            .setContentTitle("Intruder caught")
            .setContentText("Wrong password on ${labelOf(c, pkg)}. Tap to see the selfie.")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(c).notify(2001, n)
        } catch (e: SecurityException) {
        }
    }
}
