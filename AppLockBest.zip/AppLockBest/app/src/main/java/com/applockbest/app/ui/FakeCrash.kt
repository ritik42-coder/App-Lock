@file:OptIn(ExperimentalFoundationApi::class)

package com.applockbest.app.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/**
 * Looks like Android's "App isn't responding" dialog.
 * onReveal != null: long-press "Wait" to reveal the real lock screen (fake-crash disguise).
 * onReveal == null: pure decoy, there is nothing behind it.
 */
@Composable
fun FakeCrashScreen(label: String, onReveal: (() -> Unit)?, onClose: () -> Unit) {
    val dark = LocalPal.current.dark
    val card = if (dark) Color(0xFF2B2B30) else Color(0xFFF4F4F8)
    val ink = if (dark) Color.White else Color(0xFF1B1B1F)
    val blue = if (dark) Color(0xFF8AB4F8) else Color(0xFF1A5BC4)
    Box(Modifier.fillMaxSize().background(Color(0xFF0A0A0C)), contentAlignment = Alignment.Center) {
        Column(
            Modifier.padding(32.dp).clip(RoundedCornerShape(28.dp)).background(card).padding(24.dp)
        ) {
            ALText("$label isn't responding", size = 19, weight = FontWeight.Medium, color = ink)
            Spacer(Modifier.height(12.dp))
            ALText("Do you want to close it?", size = 14, color = ink.copy(alpha = 0.7f))
            Spacer(Modifier.height(20.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                Box(
                    Modifier.clip(RoundedCornerShape(12.dp))
                        .combinedClickable(onClick = {}, onLongClick = { onReveal?.invoke() })
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) { ALText("Wait", size = 15, weight = FontWeight.Medium, color = blue) }
                Box(
                    Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClose)
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) { ALText("Close app", size = 15, weight = FontWeight.Medium, color = blue) }
            }
        }
    }
}
