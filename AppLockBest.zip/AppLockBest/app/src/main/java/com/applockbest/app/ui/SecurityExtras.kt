package com.applockbest.app.ui

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.applockbest.app.MainActivity
import com.applockbest.app.data.Cred
import com.applockbest.app.data.Store
import com.applockbest.app.service.AdminReceiver

private fun lockKind(): Int =
    if (Store.credType == "PATTERN") 2 else if (Store.pinLen == 6) 1 else 0

/** Second code that looks like a normal unlock but reveals nothing real. */
@Composable
fun DecoyRow() {
    val pal = LocalPal.current
    var creator by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    val isSet = Store.decoyHash.isNotEmpty()
    Column {
        ALText("Decoy code", size = 15, weight = FontWeight.SemiBold)
        ALText(
            if (isSet) "Active. Typing it opens an empty vault and empty selfies here, and a fake crash inside locked apps."
            else "A second code that looks like a real unlock but shows nothing private.",
            size = 12, color = pal.sub
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip(if (isSet) "Change" else "Set decoy code", false) {
                msg = ""
                creator = true
            }
            if (isSet) Chip("Remove", false) { Store.update { decoyHash = "" } }
        }
        if (msg.isNotEmpty()) ALText(msg, size = 12, color = pal.bad)
    }
    if (creator) {
        Dialog(onDismissRequest = { creator = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Box(Modifier.fillMaxSize()) {
                LiveBackground()
                Box(Modifier.fillMaxSize().systemBarsPadding().padding(20.dp)) {
                    CredentialCreator(
                        lockKind = lockKind(),
                        onDone = { _, _, code ->
                            if (Cred.verify(code)) {
                                msg = "The decoy must be different from your real code."
                            } else {
                                Store.update { decoyHash = Cred.hash(code) }
                            }
                            creator = false
                        },
                        onCancel = { creator = false }
                    )
                }
            }
        }
    }
}

/** Device-admin switch: while on, Android refuses to uninstall the app. */
@Composable
fun AdminRow(act: MainActivity) {
    val ctx = LocalContext.current
    val pal = LocalPal.current
    val tick = rememberResumeTick()
    var flip by remember { mutableIntStateOf(0) }
    val comp = remember { ComponentName(ctx, AdminReceiver::class.java) }
    val dpm = remember { ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager }
    val active = remember(tick, flip) { dpm.isAdminActive(comp) }
    Column {
        ALText("Uninstall protection", size = 15, weight = FontWeight.SemiBold)
        ALText(
            if (active) "On. The app cannot be uninstalled until this is switched off. Also lock the Settings app."
            else "Make the app impossible to uninstall by accident or by someone else.",
            size = 12, color = pal.sub
        )
        Spacer(Modifier.height(8.dp))
        Chip(if (active) "Turn off" else "Turn on", active) {
            if (active) {
                try {
                    dpm.removeActiveAdmin(comp)
                } catch (e: Exception) {
                }
                flip++
            } else {
                try {
                    act.startActivity(
                        Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                            .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, comp)
                            .putExtra(
                                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                                "Stops App Lock Best from being uninstalled without turning this off first."
                            )
                    )
                } catch (e: Exception) {
                }
            }
        }
    }
}
