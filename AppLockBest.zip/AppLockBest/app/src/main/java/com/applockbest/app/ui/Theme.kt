package com.applockbest.app.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.applockbest.app.data.Store
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

data class Pal(
    val dark: Boolean,
    val bg1: Color, val bg2: Color, val bg3: Color,
    val card: Color, val border: Color,
    val text: Color, val sub: Color,
    val accent: Color, val accent2: Color,
    val good: Color, val bad: Color
)

val DarkPal = Pal(
    true,
    Color(0xFF060916), Color(0xFF0B1230), Color(0xFF160B3A),
    Color(0x1AFFFFFF), Color(0x2EFFFFFF),
    Color(0xFFF2F4FF), Color(0xFF9AA3C7),
    Color(0xFF7C5CFF), Color(0xFF22D3EE),
    Color(0xFF34D399), Color(0xFFFF5C7A)
)

val LightPal = Pal(
    false,
    Color(0xFFF7F5FF), Color(0xFFEDE9FF), Color(0xFFE0F4FF),
    Color(0xCCFFFFFF), Color(0x1F5B3DF5),
    Color(0xFF16123A), Color(0xFF6A6794),
    Color(0xFF5B3DF5), Color(0xFF0EA5E9),
    Color(0xFF10B981), Color(0xFFE11D48)
)

val LocalPal = staticCompositionLocalOf { DarkPal }

@Composable
fun ALBTheme(content: @Composable () -> Unit) {
    val sys = isSystemInDarkTheme()
    val dark = when (Store.themeMode) {
        1 -> false
        2 -> true
        else -> sys
    }
    val pal = if (dark) DarkPal else LightPal
    val scheme = if (dark) darkColorScheme(
        primary = pal.accent, secondary = pal.accent2, background = pal.bg1,
        surface = pal.bg2, onBackground = pal.text, onSurface = pal.text
    ) else lightColorScheme(
        primary = pal.accent, secondary = pal.accent2, background = pal.bg1,
        surface = pal.bg2, onBackground = pal.text, onSurface = pal.text
    )
    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(LocalPal provides pal) { content() }
    }
}

@Composable
fun ALText(
    s: String,
    modifier: Modifier = Modifier,
    size: Int = 14,
    weight: FontWeight = FontWeight.Normal,
    color: Color = LocalPal.current.text,
    align: TextAlign? = null,
    maxLines: Int = Int.MAX_VALUE
) {
    Text(
        s, modifier, color = color, fontSize = size.sp, fontWeight = weight,
        textAlign = align, maxLines = maxLines, overflow = TextOverflow.Ellipsis
    )
}

fun Modifier.bounceClick(onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed) 0.93f else 1f,
        spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "bounce"
    )
    this
        .graphicsLayer { scaleX = s; scaleY = s }
        .clickable(interactionSource = src, indication = null, onClick = onClick)
}

@Composable
fun LiveBackground() {
    val pal = LocalPal.current
    val tr = rememberInfiniteTransition(label = "bg")
    val t by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(26000, easing = LinearEasing)), label = "t")
    val dots = remember {
        val r = Random(3)
        List(48) { floatArrayOf(r.nextFloat(), r.nextFloat(), r.nextFloat()) }
    }
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        drawRect(Brush.verticalGradient(listOf(pal.bg1, pal.bg2, pal.bg3)))
        val a = t * 2f * PI.toFloat()
        fun blob(cx: Float, cy: Float, r: Float, c: Color) =
            drawCircle(Brush.radialGradient(listOf(c, Color.Transparent), Offset(cx, cy), r), r, Offset(cx, cy))
        val k = if (pal.dark) 1f else 0.75f
        blob(w * (0.2f + 0.15f * sin(a)), h * (0.18f + 0.08f * kotlin.math.cos(a)), w * 0.85f, pal.accent.copy(alpha = 0.30f * k))
        blob(w * (0.85f + 0.10f * kotlin.math.cos(a)), h * (0.55f + 0.10f * sin(a)), w * 0.75f, pal.accent2.copy(alpha = 0.22f * k))
        blob(w * (0.3f + 0.10f * sin(a + 2f)), h * (0.95f + 0.04f * kotlin.math.cos(a)), w * 0.9f, Color(0xFFFF4FA3).copy(alpha = 0.16f * k))
        if (pal.dark) {
            for (d in dots) {
                val tw = 0.5f + 0.5f * sin(a * 3f + d[2] * 6.28f)
                drawCircle(Color.White.copy(alpha = 0.15f + 0.6f * tw), 1.1f + d[2] * 1.8f, Offset(d[0] * w, d[1] * h))
            }
        } else {
            for (d in dots) {
                val yy = (((d[1] - t) % 1f) + 1f) % 1f
                val c = Offset(d[0] * w + sin(a + d[2] * 6f) * 12f, yy * h)
                val r = 5f + d[2] * 22f
                drawCircle(pal.accent.copy(alpha = 0.05f), r, c)
                drawCircle(pal.accent.copy(alpha = 0.14f), r, c, style = Stroke(1.2f))
            }
        }
    }
}

@Composable
fun GlassCard(modifier: Modifier = Modifier, radius: Dp = 24.dp, content: @Composable BoxScope.() -> Unit) {
    val pal = LocalPal.current
    val shape = RoundedCornerShape(radius)
    Box(
        modifier
            .then(
                if (!pal.dark) Modifier.shadow(
                    10.dp, shape, ambientColor = pal.accent.copy(alpha = 0.25f), spotColor = pal.accent.copy(alpha = 0.25f)
                ) else Modifier
            )
            .clip(shape)
            .background(pal.card)
            .border(1.dp, pal.border, shape),
        content = content
    )
}

@Composable
fun GradientButton(text: String, modifier: Modifier = Modifier, icon: ImageVector? = null, onClick: () -> Unit) {
    val pal = LocalPal.current
    Row(
        modifier
            .bounceClick(onClick)
            .clip(RoundedCornerShape(18.dp))
            .background(Brush.horizontalGradient(listOf(pal.accent, pal.accent2)))
            .padding(horizontal = 24.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
        }
        ALText(text, weight = FontWeight.Bold, color = Color.White, size = 15)
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    val pal = LocalPal.current
    val bg by animateColorAsState(if (selected) pal.accent else Color.Transparent, tween(250), label = "chip")
    Box(
        Modifier
            .bounceClick(onClick)
            .clip(RoundedCornerShape(14.dp))
            .background(bg)
            .border(1.dp, if (selected) pal.accent else pal.border, RoundedCornerShape(14.dp))
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        ALText(text, size = 13, weight = FontWeight.SemiBold, color = if (selected) Color.White else pal.text)
    }
}

@Composable
fun LockToggle(checked: Boolean, onChange: (Boolean) -> Unit) {
    val pal = LocalPal.current
    val p by animateFloatAsState(
        if (checked) 1f else 0f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow), label = "tg"
    )
    val off = if (pal.dark) Color(0x33FFFFFF) else Color(0x335B3DF5)
    Box(
        Modifier
            .width(56.dp).height(32.dp)
            .clip(CircleShape)
            .background(lerp(off, pal.accent, p.coerceIn(0f, 1f)))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onChange(!checked) }
    ) {
        Box(
            Modifier
                .padding(4.dp)
                .offset(x = 24.dp * p)
                .size(24.dp)
                .clip(CircleShape)
                .background(Color.White),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (checked) Icons.Rounded.Lock else Icons.Rounded.LockOpen, null,
                tint = if (checked) pal.accent else Color(0xFF9CA3AF), modifier = Modifier.size(14.dp)
            )
        }
    }
}

@Composable
fun HeroOrb(active: Boolean, modifier: Modifier = Modifier) {
    val pal = LocalPal.current
    val tr = rememberInfiniteTransition(label = "orb")
    val rot by tr.animateFloat(0f, 360f, infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "rot")
    val pulse by tr.animateFloat(
        0f, 1f, infiniteRepeatable(tween(2400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse"
    )
    val glow by animateFloatAsState(if (active) 1f else 0.3f, tween(900), label = "glow")
    Canvas(modifier.size(240.dp)) {
        val c = center
        val r = size.minDimension / 2
        drawCircle(Brush.radialGradient(listOf(pal.accent.copy(alpha = 0.55f * glow), Color.Transparent), c, r), r, c)
        for (k in 0..2) {
            val rr = r * (0.55f + 0.14f * k + 0.04f * pulse)
            drawCircle(pal.accent2.copy(alpha = (0.35f - 0.09f * k) * glow), rr, c, style = Stroke(1.5.dp.toPx()))
        }
        rotate(rot, c) {
            drawArc(
                brush = Brush.sweepGradient(
                    listOf(Color.Transparent, pal.accent2.copy(alpha = glow), pal.accent.copy(alpha = glow)), c
                ),
                startAngle = 0f, sweepAngle = 360f, useCenter = false,
                topLeft = Offset(c.x - r * 0.72f, c.y - r * 0.72f),
                size = Size(r * 1.44f, r * 1.44f),
                style = Stroke(6.dp.toPx(), cap = StrokeCap.Round)
            )
        }
        val g = ((glow - 0.3f) / 0.7f).coerceIn(0f, 1f)
        drawCircle(
            Brush.linearGradient(
                listOf(lerp(Color(0xFF6B7280), pal.accent, g), lerp(Color(0xFF9CA3AF), pal.accent2, g)),
                Offset(c.x - r * 0.4f, c.y - r * 0.4f), Offset(c.x + r * 0.4f, c.y + r * 0.4f)
            ),
            r * 0.46f + pulse * 4.dp.toPx(), c
        )
    }
}
