package com.applockbest.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.applockbest.app.data.Cred
import com.applockbest.app.data.Store

@Composable
private fun StyleThumb(st: LockStyle?, selected: Boolean, onClick: () -> Unit) {
    val pal = LocalPal.current
    val shape = RoundedCornerShape(16.dp)
    Box(
        Modifier.width(92.dp).height(150.dp).bounceClick(onClick).clip(shape)
            .border(if (selected) 3.dp else 1.dp, if (selected) pal.accent else pal.border, shape)
    ) {
        if (st != null) {
            LockBackground(st.id, pal.dark)
            ALText(
                st.name, size = 11, weight = FontWeight.Bold, color = styleInk(st.id, pal.dark),
                modifier = Modifier.align(Alignment.BottomCenter).padding(6.dp), align = TextAlign.Center, maxLines = 2
            )
        } else {
            Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(pal.accent, pal.accent2))))
            ALText(
                "Default", size = 12, weight = FontWeight.Bold, color = Color.White,
                modifier = Modifier.align(Alignment.Center)
            )
        }
    }
}

/** Per-app customisation: own lock style, message, selfie switch and own passcode. */
@Composable
fun AppConfigDialog(app: AppInfo, onClose: () -> Unit) {
    val pal = LocalPal.current
    val cfg = Store.cfg(app.pkg)
    var preview by remember { mutableStateOf<String?>(null) }
    var creator by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize()) {
            LiveBackground()
            Column(
                Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (app.icon != null) Image(app.icon, null, Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)))
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        ALText(app.label, size = 20, weight = FontWeight.Black, maxLines = 1)
                        ALText("Custom lock for this app", size = 12, color = pal.sub)
                    }
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(pal.card).bounceClick(onClose),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Rounded.Close, null, tint = pal.text) }
                }

                Section("Lock screen style") {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        item { StyleThumb(null, cfg.style.isEmpty()) { Store.setCfg(app.pkg, cfg.copy(style = "")) } }
                        items(LockStyles) { st ->
                            StyleThumb(st, cfg.style == st.id) { Store.setCfg(app.pkg, cfg.copy(style = st.id)) }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Chip("Preview this style", false) { preview = cfg.style.ifEmpty { Store.lockStyle } }
                    }
                }

                Section("Lock message") {
                    BasicTextField(
                        cfg.msg, { v -> Store.setCfg(app.pkg, cfg.copy(msg = v.take(40))) },
                        singleLine = true,
                        textStyle = TextStyle(color = pal.text, fontSize = 16.sp),
                        cursorBrush = SolidColor(pal.accent),
                        modifier = Modifier.fillMaxWidth(),
                        decorationBox = { inner ->
                            Box {
                                if (cfg.msg.isEmpty()) ALText("e.g. Private - please don't open", color = pal.sub, size = 16)
                                inner()
                            }
                        }
                    )
                    ALText("Shown under the app name on its lock screen.", size = 12, color = pal.sub)
                }

                Section("Intruder selfie") {
                    ToggleRow("Selfie for this app", "Capture a photo after wrong attempts", cfg.selfie) { v ->
                        Store.setCfg(app.pkg, cfg.copy(selfie = v))
                    }
                }

                Section("Passcode") {
                    val own = cfg.credHash.isNotEmpty()
                    ALText(
                        if (own) "Own ${if (cfg.credType == "PATTERN") "pattern" else "${cfg.pinLen}-digit PIN"} (different from the global one)"
                        else "Uses your global PIN / pattern",
                        size = 13, color = pal.sub
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Chip(if (own) "Change" else "Set own passcode", false) { creator = true }
                        if (own) Chip("Remove", false) {
                            Store.setCfg(app.pkg, cfg.copy(credType = "", pinLen = 4, credHash = ""))
                        }
                    }
                }

                GradientButton("Done", Modifier.fillMaxWidth()) { onClose() }
                Box(Modifier.height(8.dp))
            }
        }
    }

    val pv = preview
    if (pv != null) {
        Dialog(onDismissRequest = { preview = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            LockPreview(pv) { preview = null }
        }
    }
    if (creator) {
        Dialog(onDismissRequest = { creator = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Box(Modifier.fillMaxSize()) {
                LiveBackground()
                Box(Modifier.fillMaxSize().systemBarsPadding().padding(20.dp)) {
                    CredentialCreator(
                        onDone = { type, len, code ->
                            Store.setCfg(app.pkg, Store.cfg(app.pkg).copy(credType = type, pinLen = len, credHash = Cred.hash(code)))
                            creator = false
                        },
                        onCancel = { creator = false }
                    )
                }
            }
        }
    }
}
