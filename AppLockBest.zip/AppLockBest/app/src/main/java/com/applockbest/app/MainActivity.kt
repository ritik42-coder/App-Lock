package com.applockbest.app

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.applockbest.app.camera.IntruderCam
import com.applockbest.app.camera.askBiometric
import com.applockbest.app.camera.canBiometric
import com.applockbest.app.data.Store
import com.applockbest.app.ui.ALBTheme
import com.applockbest.app.ui.HomeShell
import com.applockbest.app.ui.IntroScreen
import com.applockbest.app.ui.LocalPal
import com.applockbest.app.ui.LockScreen
import com.applockbest.app.ui.SetupFlow

class MainActivity : FragmentActivity() {
    val cam by lazy { IntruderCam(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Store.init(this)
        setContent { ALBTheme { AppRoot(this) } }
    }
}

@Composable
fun AppRoot(act: MainActivity) {
    // 0 intro, 1 setup, 2 gate (unlock the app itself), 3 home
    var stage by rememberSaveable { mutableIntStateOf(0) }
    var stopAt by remember { mutableLongStateOf(0L) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_STOP) stopAt = System.currentTimeMillis()
            if (e == Lifecycle.Event.ON_START && stage == 3 && stopAt > 0L &&
                System.currentTimeMillis() - stopAt > 15_000L && Store.credHash.isNotEmpty()
            ) stage = 2
        }
        owner.lifecycle.addObserver(o)
        onDispose { owner.lifecycle.removeObserver(o) }
    }
    AnimatedContent(
        stage,
        transitionSpec = { fadeIn(tween(700)) togetherWith fadeOut(tween(500)) },
        label = "root"
    ) { s ->
        when (s) {
            0 -> IntroScreen { stage = if (Store.credHash.isEmpty()) 1 else 2 }
            1 -> SetupFlow(act) { stage = 3 }
            2 -> Gate(act) { stage = 3 }
            else -> HomeShell(act)
        }
    }
}

@Composable
private fun Gate(act: MainActivity, onOk: () -> Unit) {
    val dark = LocalPal.current.dark
    DisposableEffect(Unit) {
        act.cam.prepare()
        onDispose { act.cam.release() }
    }
    val bioFn: (() -> Unit) -> Unit = { cb -> act.askBiometric(cb) }
    val bio = if (canBiometric(act)) bioFn else null
    Box(Modifier.fillMaxSize()) {
        LockScreen(
            title = "Welcome back",
            subtitle = "Unlock App Lock Best",
            icon = null,
            styleId = Store.lockStyle,
            dark = dark,
            onSuccess = onOk,
            onWrong = { c -> if (Store.intruderOn && c % Store.intruderAttempts == 0) act.cam.snap(act.packageName) },
            biometric = bio,
            autoBiometric = true
        )
    }
}
