package com.applockbest.app

import android.app.Application
import com.applockbest.app.data.Notifier
import com.applockbest.app.data.Store

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        Notifier.channels(this)
    }
}
