package com.applockbest.app.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.applockbest.app.MainActivity
import com.applockbest.app.data.Intruder
import com.applockbest.app.data.Intruders
import com.applockbest.app.data.Notifier
import com.applockbest.app.data.Store
import com.applockbest.app.data.labelOf
import com.applockbest.app.service.Disguise
import com.applockbest.app.service.ReportScheduler
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
private fun StepBtn(label: String, onClick: () -> Unit) {
    val pal = LocalPal.current
    Box(
        Modifier.size(34.dp).clip(CircleShape).background(pal.accent.copy(alpha = 0.18f)).bounceClick(onClick),
        contentAlignment = Alignment.Center
    ) { ALText(label, size = 18, weight = FontWeight.Bold, color = pal.accent) }
}

/** Simple 12-hour time chooser: hour -/+, minute -/+ (5 min), AM/PM. minutes = minutes since midnight. */
@Composable
fun TimeStepper(label: String, minutes: Int, onChange: (Int) -> Unit) {
    val pal = LocalPal.current
    val h24 = minutes / 60
    val m = minutes % 60
    val h12 = (h24 + 11) % 12 + 1
    val pm = h24 >= 12
    Column {
        ALText(label, size = 14, weight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            StepBtn("-") { onChange(((h24 + 23) % 24) * 60 + m) }
            ALText("%02d".format(h12), size = 20, weight = FontWeight.Black, modifier = Modifier.width(28.dp), align = TextAlign.Center)
            StepBtn("+") { onChange(((h24 + 1) % 24) * 60 + m) }
            ALText(":", size = 20, weight = FontWeight.Black)
            StepBtn("-") { onChange(h24 * 60 + (m + 55) % 60) }
            ALText("%02d".format(m), size = 20, weight = FontWeight.Black, modifier = Modifier.width(28.dp), align = TextAlign.Center)
            StepBtn("+") { onChange(h24 * 60 + (m + 5) % 60) }
            Spacer(Modifier.width(4.dp))
            Chip(if (pm) "PM" else "AM", true) { onChange((minutes + 720) % 1440) }
        }
    }
}

/** Round-3 settings: daily report, schedule, icon disguise, quiet notification. */
@Composable
fun Build3Settings(act: MainActivity) {
    val ctx = LocalContext.current
    val pal = LocalPal.current

    Section("Daily intruder report") {
        ToggleRow(
            "Send a daily reminder",
            "No alert appears when a photo is taken. Once a day, at your time, you get one notification - only if intruder photos exist.",
            Store.dailyOn
        ) { v ->
            Store.update { dailyOn = v }
            ReportScheduler.schedule(ctx)
        }
        TimeStepper("Send at", Store.dailyHour * 60 + Store.dailyMin) { m ->
            Store.update {
                dailyHour = m / 60
                dailyMin = m % 60
            }
            ReportScheduler.schedule(ctx)
        }
        ALText("Allow the Notifications permission below for this to show. Android may deliver it a few minutes late.", size = 11, color = pal.sub)
    }

    Section("Smart schedule") {
        ToggleRow(
            "Lock only during set hours",
            "Outside this window your apps open without the lock (for example only lock at night).",
            Store.schedOn
        ) { v -> Store.update { schedOn = v } }
        if (Store.schedOn) {
            TimeStepper("Lock from", Store.schedStart) { m -> Store.update { schedStart = m } }
            TimeStepper("Lock until", Store.schedEnd) { m -> Store.update { schedEnd = m } }
        }
    }

    Section("App icon disguise") {
        ChipRow("Launcher icon", listOf("Default", "Calculator", "Clock", "Notes"), Store.disguise) { i ->
            Store.update { disguise = i }
            Disguise.apply(ctx, i)
        }
        ALText(
            "Changes the home-screen icon and name. It can take a few seconds to appear, and some launchers need a restart to refresh.",
            size = 11, color = pal.sub
        )
    }

    Section("Status-bar notice") {
        ALText(
            "Android requires a background-service notice. It is already set to silent and minimal. Turn that channel off to hide it completely - protection keeps working.",
            size = 12, color = pal.sub
        )
        Chip("Open notification settings", false) {
            try {
                act.startActivity(
                    Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                        .putExtra(Settings.EXTRA_CHANNEL_ID, Notifier.CH_SERVICE)
                )
            } catch (e: Exception) {
            }
        }
    }
}

/** 7-day bar chart of intruder photos + most targeted app. */
@Composable
fun ReportCard() {
    val ctx = LocalContext.current
    val pal = LocalPal.current
    val list = remember(Store.intruderTick, Store.decoyActive) {
        if (Store.decoyActive) emptyList<Intruder>() else Intruders.list(ctx)
    }
    val data = remember(list) {
        val counts = ArrayList<Int>()
        val labels = ArrayList<String>()
        val f = SimpleDateFormat("EEE", Locale.getDefault())
        for (i in 6 downTo 0) {
            val c = Calendar.getInstance()
            c.add(Calendar.DAY_OF_YEAR, -i)
            c.set(Calendar.HOUR_OF_DAY, 0)
            c.set(Calendar.MINUTE, 0)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            val start = c.timeInMillis
            val end = start + 86_400_000L
            counts.add(list.count { it.time >= start && it.time < end })
            labels.add(f.format(Date(start)))
        }
        Pair(counts, labels)
    }
    val counts = data.first
    val labels = data.second
    val max = (counts.maxOrNull() ?: 0).coerceAtLeast(1)
    var go by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { go = true }
    val p by animateFloatAsState(if (go) 1f else 0f, tween(900), label = "bars")
    val weekTotal = counts.sum()
    val top = list.groupBy { it.pkg }.maxByOrNull { it.value.size }

    GlassCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            ALText("Security report", size = 16, weight = FontWeight.Bold)
            ALText(
                if (weekTotal == 0) "No intruders in the last 7 days." else "$weekTotal intruder photo(s) in the last 7 days.",
                size = 12, color = pal.sub
            )
            Spacer(Modifier.height(12.dp))
            Canvas(Modifier.fillMaxWidth().height(100.dp)) {
                val cw = size.width / 7f
                val minH = 6.dp.toPx()
                for (i in 0 until 7) {
                    val frac = counts[i] / max.toFloat()
                    val bh = (minH + (size.height - minH) * frac * p).coerceAtMost(size.height)
                    val bw = cw * 0.5f
                    val x = i * cw + (cw - bw) / 2f
                    val brush = if (counts[i] > 0) {
                        Brush.verticalGradient(listOf(pal.accent2, pal.accent), startY = size.height - bh, endY = size.height)
                    } else {
                        SolidColor(pal.border)
                    }
                    drawRoundRect(brush, Offset(x, size.height - bh), Size(bw, bh), CornerRadius(bw / 2f))
                }
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth()) {
                for (i in 0 until 7) {
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        ALText("${counts[i]}", size = 12, weight = FontWeight.Bold, color = if (counts[i] > 0) pal.accent else pal.sub)
                        ALText(labels[i], size = 10, color = pal.sub)
                    }
                }
            }
            if (top != null) {
                Spacer(Modifier.height(8.dp))
                ALText("Most targeted: ${labelOf(ctx, top.key)} (${top.value.size})", size = 12, color = pal.sub)
            }
        }
    }
}
