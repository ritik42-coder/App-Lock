package com.applockbest.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import kotlin.math.hypot
import kotlin.math.min

/** Success animation played over the lock screen. kind: 0 check burst, 1 padlock opens, 2 portal. */
@Composable
fun UnlockFx(kind: Int) {
    val p = remember { Animatable(0f) }
    LaunchedEffect(Unit) { p.animateTo(1f, tween(620, easing = FastOutSlowInEasing)) }
    Canvas(Modifier.fillMaxSize()) {
        val v = p.value
        val w = size.width
        val h = size.height
        val c = Offset(w / 2f, h / 2f)
        val maxR = hypot(w, h) / 2f
        val green = Color(0xFF34D399)
        when (kind) {
            1 -> {
                val l = min(w, h) * 0.26f
                val pop = minOf(1f, v * 3f)
                drawCircle(
                    Brush.radialGradient(listOf(green.copy(alpha = 0.5f * (1f - v * 0.6f)), Color.Transparent), c, l * 2.4f),
                    l * 2.4f, c
                )
                scale(0.6f + 0.4f * pop, c) {
                    val lift = -l * 0.42f * minOf(1f, v * 1.6f)
                    val r = l * 0.34f
                    val bodyTop = c.y - l * 0.1f
                    val bodyH = l * 0.78f
                    val acy = bodyTop - l * 0.2f + lift
                    val sh = Path().apply {
                        moveTo(c.x - r, bodyTop + lift)
                        lineTo(c.x - r, acy)
                        arcTo(androidx.compose.ui.geometry.Rect(c.x - r, acy - r, c.x + r, acy + r), 180f, 180f, false)
                        lineTo(c.x + r, bodyTop + lift)
                    }
                    drawPath(sh, Color.White, style = Stroke(l * 0.11f, cap = StrokeCap.Round))
                    drawRoundRect(
                        Brush.verticalGradient(listOf(Color(0xFF6EE7B7), Color(0xFF059669)), startY = bodyTop, endY = bodyTop + bodyH),
                        Offset(c.x - l / 2f, bodyTop), Size(l, bodyH), CornerRadius(l * 0.16f)
                    )
                    drawCircle(Color.White, l * 0.09f, Offset(c.x, bodyTop + bodyH * 0.42f))
                }
            }

            2 -> {
                for (k in 0..2) {
                    val pv = ((v - k * 0.12f) / 0.88f).coerceIn(0f, 1f)
                    drawCircle(Color(0xFF22D3EE).copy(alpha = (1f - pv) * 0.9f), pv * maxR, c, style = Stroke(10f * (1f - pv) + 2f))
                }
                val rr = 40f + v * maxR * 0.9f
                drawCircle(
                    Brush.radialGradient(listOf(Color.White.copy(alpha = 0.85f), green.copy(alpha = 0.6f), Color.Transparent), c, rr),
                    rr, c
                )
            }

            else -> {
                val r = min(w, h) * 0.14f * (0.6f + 0.4f * minOf(1f, v * 2.5f))
                drawCircle(green, r, c)
                for (k in 0..1) {
                    val pv = ((v - k * 0.15f) / 0.85f).coerceIn(0f, 1f)
                    drawCircle(green.copy(alpha = (1f - pv) * 0.7f), r + pv * r * 2.4f, c, style = Stroke(6f))
                }
                val path = Path().apply {
                    moveTo(c.x - r * 0.45f, c.y)
                    lineTo(c.x - r * 0.1f, c.y + r * 0.35f)
                    lineTo(c.x + r * 0.5f, c.y - r * 0.35f)
                }
                val pm = PathMeasure()
                pm.setPath(path, false)
                val part = Path()
                pm.getSegment(0f, pm.length * ((v - 0.15f) / 0.5f).coerceIn(0f, 1f), part, true)
                drawPath(part, Color.White, style = Stroke(r * 0.16f, cap = StrokeCap.Round))
            }
        }
    }
}
