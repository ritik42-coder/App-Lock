package com.applockbest.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.applockbest.app.data.Store
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val BAD = Color(0xFFFF5C7A)
private val GOOD = Color(0xFF34D399)

@Composable
fun LockScreen(
    title: String,
    subtitle: String,
    icon: ImageBitmap?,
    styleId: String,
    dark: Boolean,
    onSuccess: () -> Unit,
    onWrong: (Int) -> Unit,
    biometric: ((onOk: () -> Unit) -> Unit)?,
    autoBiometric: Boolean,
    credType: String,
    pinLen: Int,
    verify: (String) -> Boolean,
    message: String,
    unlockFx: Int,
    isDecoy: (String) -> Boolean,
    onDecoy: () -> Unit
) {
    val ink = styleInk(styleId, dark)
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    var input by remember { mutableStateOf("") }
    var wrong by remember { mutableIntStateOf(0) }
    var err by remember { mutableStateOf(false) }
    var ok by remember { mutableStateOf(false) }
    var decoyHit by remember { mutableStateOf(false) }
    var lockUntil by remember { mutableLongStateOf(0L) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var shuffleKey by remember { mutableIntStateOf(0) }
    var shown by remember { mutableStateOf(false) }
    val shake = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        shown = true
        if (autoBiometric) biometric?.invoke { ok = true }
    }
    LaunchedEffect(lockUntil) {
        while (System.currentTimeMillis() < lockUntil) {
            now = System.currentTimeMillis()
            delay(250)
        }
        now = System.currentTimeMillis()
    }
    LaunchedEffect(ok) {
        if (ok) {
            delay(650)
            if (decoyHit) onDecoy() else onSuccess()
        }
    }
    val blocked = now < lockUntil
    val contentAlpha by animateFloatAsState(if (ok) 0f else 1f, tween(250), label = "ca")

    fun fail() {
        wrong++
        err = true
        if (Store.haptics) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        onWrong(wrong)
        if (wrong % 5 == 0) lockUntil = System.currentTimeMillis() + 30_000L
        scope.launch {
            for (v in listOf(-26f, 26f, -18f, 18f, -9f, 9f, 0f)) shake.animateTo(v, tween(50))
            delay(250)
            err = false
            input = ""
            shuffleKey++
        }
    }

    fun digit(d: Char) {
        if (input.length < pinLen) {
            input += d
            if (input.length == pinLen) {
                if (verify(input)) ok = true
                else if (isDecoy(input)) {
                    decoyHit = true
                    ok = true
                } else fail()
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        LockBackground(styleId, dark)
        Column(
            Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .padding(horizontal = 24.dp)
                .graphicsLayer { alpha = contentAlpha },
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(20.dp))
            AnimatedVisibility(
                shown,
                enter = fadeIn(tween(600)) + scaleIn(spring(Spring.DampingRatioMediumBouncy), initialScale = 0.3f)
            ) { AppBadge(icon, ink, err, ok) }
            Spacer(Modifier.height(14.dp))
            AnimatedVisibility(shown, enter = fadeIn(tween(800)) + slideInVertically(tween(700)) { it }) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    ALText(title, size = 22, weight = FontWeight.Bold, color = ink, align = TextAlign.Center, maxLines = 1)
                    Spacer(Modifier.height(4.dp))
                    val msg = when {
                        blocked -> "Too many attempts · wait ${(lockUntil - now) / 1000 + 1}s"
                        err -> "Wrong ${if (credType == "PATTERN") "pattern" else "PIN"} · attempt $wrong"
                        else -> if (message.isNotEmpty()) message else subtitle
                    }
                    ALText(msg, size = 13, color = if (blocked || err) BAD else ink.copy(alpha = 0.7f), align = TextAlign.Center)
                }
            }
            Spacer(Modifier.weight(1f))
            if (credType == "PATTERN") {
                PatternPad(
                    Modifier.widthIn(max = 290.dp).fillMaxWidth(0.82f),
                    ink = ink, accent = if (dark || styleId != "glass") Color(0xFF8B6CFF) else Color(0xFF5B3DF5),
                    hidePath = Store.hidePath, error = err
                ) { code ->
                    if (!blocked && !err && !ok) {
                        if (code.length < 4) {
                            err = true
                            scope.launch { delay(500); err = false }
                        } else if (verify(code)) ok = true
                        else if (isDecoy(code)) {
                            decoyHit = true
                            ok = true
                        } else fail()
                    }
                }
                if (biometric != null) {
                    Spacer(Modifier.height(18.dp))
                    Icon(
                        Icons.Rounded.Fingerprint, null, tint = ink,
                        modifier = Modifier
                            .size(44.dp)
                            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                                biometric { ok = true }
                            }
                    )
                }
            } else {
                PinDots(pinLen, input.length, ink, err, shake.value)
                Spacer(Modifier.height(26.dp))
                PinPad(
                    ink, Store.shuffle, shuffleKey, !blocked && !err && !ok,
                    onDigit = { digit(it) },
                    onDelete = { if (input.isNotEmpty()) input = input.dropLast(1) },
                    onBiometric = if (biometric != null) ({ biometric { ok = true } }) else null
                )
            }
            Spacer(Modifier.height(18.dp))
        }
        if (ok) UnlockFx(unlockFx)
    }
}

@Composable
private fun AppBadge(icon: ImageBitmap?, ink: Color, err: Boolean, ok: Boolean) {
    val tr = rememberInfiniteTransition(label = "badge")
    val p by tr.animateFloat(
        0f, 1f, infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p"
    )
    val ring = if (ok) GOOD else if (err) BAD else ink
    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(112.dp)) {
        Box(
            Modifier
                .size(112.dp)
                .graphicsLayer { scaleX = 0.88f + 0.12f * p; scaleY = scaleX; alpha = 0.55f - 0.35f * p }
                .border(2.dp, ring, CircleShape)
        )
        Box(
            Modifier
                .size(88.dp)
                .clip(CircleShape)
                .background(ink.copy(alpha = 0.12f))
                .border(1.dp, ring.copy(alpha = 0.6f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (icon != null) {
                Image(icon, null, Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)))
            } else {
                Icon(Icons.Rounded.Lock, null, tint = ink, modifier = Modifier.size(40.dp))
            }
        }
    }
}

@Composable
fun LockPreview(id: String, onClose: () -> Unit) {
    val pal = LocalPal.current
    val ink = styleInk(id, pal.dark)
    Box(
        Modifier
            .fillMaxSize()
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClose)
    ) {
        LockBackground(id, pal.dark)
        Column(
            Modifier.fillMaxSize().systemBarsPadding().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(20.dp))
            AppBadge(null, ink, false, false)
            Spacer(Modifier.height(14.dp))
            ALText("Preview", size = 22, weight = FontWeight.Bold, color = ink)
            ALText("Tap anywhere to close", size = 13, color = ink.copy(alpha = 0.7f))
            Spacer(Modifier.weight(1f))
            PinDots(4, 2, ink, false, 0f)
            Spacer(Modifier.height(26.dp))
            PinPad(ink, false, 0, false, {}, {}, null)
            Spacer(Modifier.height(18.dp))
        }
    }
}
