@file:OptIn(ExperimentalFoundationApi::class)

package com.applockbest.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.graphics.drawable.toBitmap
import com.applockbest.app.MainActivity
import com.applockbest.app.data.Cred
import com.applockbest.app.data.Intruder
import com.applockbest.app.data.Intruders
import com.applockbest.app.data.Perms
import com.applockbest.app.data.Store
import com.applockbest.app.data.labelOf
import com.applockbest.app.service.LockService
import com.applockbest.app.service.LockWidget
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

private val TABS = listOf(
    "Home" to Icons.Rounded.Home,
    "Apps" to Icons.Rounded.Apps,
    "Selfies" to Icons.Rounded.PhotoCamera,
    "Vault" to Icons.Rounded.Folder,
    "Styles" to Icons.Rounded.Palette,
    "Settings" to Icons.Rounded.Settings
)

private val ESSENTIALS = listOf(
    "com.android.settings", "com.android.vending", "com.whatsapp", "com.instagram.android",
    "com.facebook.katana", "com.google.android.gm", "com.google.android.apps.photos",
    "com.android.chrome", "org.telegram.messenger", "com.snapchat.android",
    "com.google.android.apps.messaging", "com.google.android.packageinstaller", "com.android.packageinstaller"
)

data class AppInfo(val pkg: String, val label: String, val icon: ImageBitmap?)

fun loadApps(c: Context): List<AppInfo> {
    val pm = c.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0).map { ri ->
        AppInfo(
            ri.activityInfo.packageName,
            ri.loadLabel(pm).toString(),
            try {
                ri.loadIcon(pm).toBitmap(96, 96).asImageBitmap()
            } catch (e: Exception) {
                null
            }
        )
    }.filter { it.pkg != c.packageName }.distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
}

private fun fmt(t: Long): String = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(t))

@Composable
fun HomeShell(act: MainActivity) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val ctx = LocalContext.current
    LaunchedEffect(Unit) {
        if (Store.serviceOn && Perms.coreReady(ctx)) LockService.start(ctx)
    }
    Box(Modifier.fillMaxSize()) {
        LiveBackground()
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            Header()
            Box(Modifier.weight(1f)) {
                AnimatedContent(
                    tab,
                    transitionSpec = {
                        val dir = if (targetState > initialState) 1 else -1
                        (slideInHorizontally(tween(380)) { it / 4 * dir } + fadeIn(tween(380))) togetherWith
                            (slideOutHorizontally(tween(300)) { -it / 4 * dir } + fadeOut(tween(200)))
                    },
                    label = "tabs"
                ) { t ->
                    when (t) {
                        0 -> HomeTab(act)
                        1 -> AppsTab()
                        2 -> SelfiesTab(act)
                        3 -> VaultTab()
                        4 -> StylesTab()
                        else -> SettingsTab(act)
                    }
                }
            }
            NavBar(tab) { tab = it }
        }
    }
}

@Composable
private fun Header() {
    val pal = LocalPal.current
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(40.dp).clip(RoundedCornerShape(13.dp))
                .background(Brush.linearGradient(listOf(pal.accent, pal.accent2))),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.Shield, null, tint = Color.White, modifier = Modifier.size(24.dp)) }
        Column(Modifier.padding(start = 12.dp)) {
            ALText("App Lock Best", size = 20, weight = FontWeight.Black)
            ALText("Premium app protection", size = 12, color = pal.sub)
        }
    }
}

@Composable
private fun NavBar(tab: Int, onTab: (Int) -> Unit) {
    val pal = LocalPal.current
    GlassCard(Modifier.padding(horizontal = 14.dp, vertical = 10.dp).fillMaxWidth(), radius = 30.dp) {
        Row(
            Modifier.fillMaxWidth().padding(6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TABS.forEachIndexed { i, (name, icon) ->
                val sel = tab == i
                val bg by animateColorAsState(if (sel) pal.accent else Color.Transparent, tween(300), label = "nb")
                Row(
                    Modifier
                        .bounceClick { onTab(i) }
                        .clip(RoundedCornerShape(22.dp))
                        .background(bg)
                        .padding(horizontal = if (sel) 12.dp else 8.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(icon, name, tint = if (sel) Color.White else pal.sub, modifier = Modifier.size(22.dp))
                    AnimatedVisibility(
                        sel,
                        enter = expandHorizontally(tween(300)) + fadeIn(tween(300)),
                        exit = shrinkHorizontally(tween(250)) + fadeOut(tween(150))
                    ) {
                        ALText(name, size = 13, weight = FontWeight.SemiBold, color = Color.White,
                            modifier = Modifier.padding(start = 6.dp), maxLines = 1)
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- HOME

@Composable
private fun StatCard(label: String, value: Int, modifier: Modifier) {
    val pal = LocalPal.current
    val v by animateIntAsState(value, tween(900), label = "stat")
    GlassCard(modifier, radius = 20.dp) {
        Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            ALText("$v", size = 28, weight = FontWeight.Black, color = pal.accent)
            ALText(label, size = 12, color = pal.sub)
        }
    }
}

@Composable
private fun HomeTab(act: MainActivity) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    val tick = rememberResumeTick()
    val ready = remember(tick) { Perms.coreReady(ctx) }
    val on = Store.serviceOn && ready
    val scope = rememberCoroutineScope()
    var msg by remember { mutableStateOf<String?>(null) }
    val intruders = remember(Store.intruderTick, tick, Store.decoyActive) { if (Store.decoyActive) 0 else Intruders.list(ctx).size }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(contentAlignment = Alignment.Center) {
            HeroOrb(on)
            Icon(if (on) Icons.Rounded.Lock else Icons.Rounded.LockOpen, null, tint = Color.White, modifier = Modifier.size(68.dp))
        }
        ALText(if (on) "PROTECTION ACTIVE" else "PROTECTION OFF", size = 20, weight = FontWeight.Black, color = if (on) pal.good else pal.sub)
        ALText("${Store.lockedApps.size} apps guarded", size = 13, color = pal.sub)
        Spacer(Modifier.height(14.dp))
        GradientButton(if (on) "Pause protection" else "Activate protection", Modifier.fillMaxWidth(), if (on) Icons.Rounded.LockOpen else Icons.Rounded.Lock) {
            if (!ready) {
                msg = "Grant Usage access and Display over other apps first."
            } else if (Store.serviceOn) {
                LockService.stop(ctx)
                Store.update { serviceOn = false }
                LockWidget.refresh(ctx)
            } else {
                LockService.start(ctx)
                Store.update { serviceOn = true }
                LockWidget.refresh(ctx)
                msg = null
            }
        }
        if (msg != null) {
            Spacer(Modifier.height(8.dp))
            ALText(msg ?: "", size = 12, color = pal.bad, align = TextAlign.Center)
        }
        if (!ready) {
            Spacer(Modifier.height(14.dp))
            PermissionsPanel(act)
        }
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Locked apps", Store.lockedApps.size, Modifier.weight(1f))
            StatCard("Intruders", intruders, Modifier.weight(1f))
            StatCard("Wrong tries", Store.intruderAttempts, Modifier.weight(1f))
        }
        Spacer(Modifier.height(16.dp))
        ReportCard()
        Spacer(Modifier.height(16.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                ALText("Quick actions", size = 16, weight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Chip("Lock essentials", false) {
                        scope.launch {
                            val found = withContext(Dispatchers.Default) {
                                ESSENTIALS.filter { ctx.packageManager.getLaunchIntentForPackage(it) != null }
                            }
                            Store.update { lockedApps = lockedApps + found }
                        }
                    }
                    Chip("Unlock all", false) { Store.update { lockedApps = emptySet() } }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Chip("Pause 15 min", false) { Store.update { pauseUntil = System.currentTimeMillis() + 15 * 60_000L } }
                    Chip("Pause 1 hour", false) { Store.update { pauseUntil = System.currentTimeMillis() + 60 * 60_000L } }
                    if (System.currentTimeMillis() < Store.pauseUntil) Chip("Resume", true) { Store.update { pauseUntil = 0L } }
                }
                Spacer(Modifier.height(8.dp))
                ALText("Essentials = Settings, Play Store, WhatsApp, Instagram, Gmail, Photos and more (only those installed).", size = 11, color = pal.sub)
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

// ---------------------------------------------------------------- APPS

@Composable
private fun AppsTab() {
    val ctx = LocalContext.current
    val pal = LocalPal.current
    val apps by produceState<List<AppInfo>?>(null) {
        value = withContext(Dispatchers.Default) { loadApps(ctx) }
    }
    var q by remember { mutableStateOf("") }
    var onlyLocked by remember { mutableStateOf(false) }
    val state = rememberLazyListState()
    var cfgFor by remember { mutableStateOf<AppInfo?>(null) }

    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        GlassCard(Modifier.fillMaxWidth(), radius = 18.dp) {
            Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Search, null, tint = pal.sub, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
                BasicTextField(
                    q, { q = it }, singleLine = true,
                    textStyle = TextStyle(color = pal.text, fontSize = 16.sp),
                    cursorBrush = SolidColor(pal.accent),
                    modifier = Modifier.weight(1f),
                    decorationBox = { inner ->
                        Box {
                            if (q.isEmpty()) ALText("Search apps", color = pal.sub, size = 16)
                            inner()
                        }
                    }
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Chip("All", !onlyLocked) { onlyLocked = false }
            Chip("Locked (${Store.lockedApps.size})", onlyLocked) { onlyLocked = true }
        }
        Spacer(Modifier.height(10.dp))
        val list = apps
        if (list == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Spinner() }
        } else {
            val shown = list.filter {
                (q.isBlank() || it.label.contains(q, true)) && (!onlyLocked || it.pkg in Store.lockedApps)
            }
            LazyColumn(state = state, verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
                items(shown, key = { it.pkg }) { app ->
                    AppRow(app, shown.indexOf(app), state, Modifier.animateItemPlacement()) { cfgFor = app }
                }
            }
        }
    }
    val cf = cfgFor
    if (cf != null) AppConfigDialog(cf) { cfgFor = null }
}

@Composable
private fun Spinner() {
    val pal = LocalPal.current
    val tr = androidx.compose.animation.core.rememberInfiniteTransition(label = "sp")
    val r by tr.animateFloat(
        0f, 360f,
        androidx.compose.animation.core.infiniteRepeatable(tween(900, easing = androidx.compose.animation.core.LinearEasing)),
        label = "r"
    )
    androidx.compose.foundation.Canvas(Modifier.size(48.dp)) {
        drawArc(
            brush = Brush.sweepGradient(listOf(Color.Transparent, pal.accent, pal.accent2)),
            startAngle = r, sweepAngle = 270f, useCenter = false,
            style = androidx.compose.ui.graphics.drawscope.Stroke(5.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
        )
    }
}

@Composable
private fun AppRow(app: AppInfo, idx: Int, state: LazyListState, modifier: Modifier, onTune: () -> Unit) {
    val pal = LocalPal.current
    val locked = app.pkg in Store.lockedApps
    var vis by remember { mutableStateOf(idx > 12 || idx < 0) }
    LaunchedEffect(Unit) {
        if (!vis) {
            delay(idx * 45L)
            vis = true
        }
    }
    val border by animateColorAsState(if (locked) pal.accent else Color.Transparent, tween(300), label = "rowb")
    Box(
        modifier.graphicsLayer {
            val li = state.layoutInfo
            val item = li.visibleItemsInfo.firstOrNull { v -> v.key == app.pkg }
            if (item != null) {
                val half = ((li.viewportEndOffset - li.viewportStartOffset) / 2f).coerceAtLeast(1f)
                val d = ((item.offset + item.size / 2f - (li.viewportStartOffset + half)) / half).coerceIn(-1f, 1f)
                val a = abs(d)
                scaleX = 1f - 0.08f * a * a
                scaleY = scaleX
                alpha = 1f - 0.45f * a * a
                rotationX = d * 8f
                cameraDistance = 14f * density
            }
        }
    ) {
        AnimatedVisibility(vis, enter = fadeIn(tween(400)) + slideInHorizontally(tween(450)) { it / 2 }) {
            GlassCard(Modifier.fillMaxWidth().border(1.5.dp, border, RoundedCornerShape(24.dp)), radius = 24.dp) {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (app.icon != null) {
                        Image(app.icon, null, Modifier.size(46.dp).clip(RoundedCornerShape(12.dp)))
                    } else {
                        Box(Modifier.size(46.dp).clip(RoundedCornerShape(12.dp)).background(pal.border))
                    }
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        ALText(app.label, size = 15, weight = FontWeight.SemiBold, maxLines = 1)
                        ALText(if (locked) (if (Store.cfg(app.pkg).let { it.style.isNotEmpty() || it.credHash.isNotEmpty() }) "Locked · custom" else "Locked") else "Unlocked", size = 12, color = if (locked) pal.accent else pal.sub)
                    }
                    if (locked) {
                        Box(
                            Modifier.padding(end = 10.dp).size(36.dp).clip(CircleShape)
                                .background(pal.accent.copy(alpha = 0.15f)).bounceClick(onTune),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Rounded.Tune, null, tint = pal.accent, modifier = Modifier.size(18.dp)) }
                    }
                    LockToggle(locked) { want ->
                        Store.update { lockedApps = if (want) lockedApps + app.pkg else lockedApps - app.pkg }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- SELFIES

@Composable
private fun SelfiesTab(act: MainActivity) {
    val ctx = LocalContext.current
    val pal = LocalPal.current
    val tick = rememberResumeTick()
    var flip by remember { mutableIntStateOf(0) }
    val granted = remember(tick, flip) { Perms.camera(ctx) }
    val items = remember(Store.intruderTick, tick, Store.decoyActive) {
        if (Store.decoyActive) emptyList<Intruder>() else Intruders.list(ctx)
    }
    var open by remember { mutableStateOf<Intruder?>(null) }
    val camL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        flip++
        act.cam.prepare()
    }

    LazyVerticalGrid(
        GridCells.Fixed(2), Modifier.fillMaxSize(),
        contentPadding = PaddingValues(18.dp, 4.dp, 18.dp, 18.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            GlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            ALText("Intruder selfie", size = 18, weight = FontWeight.Bold)
                            ALText("Silently photographs whoever fails to unlock.", size = 12, color = pal.sub)
                        }
                        LockToggle(Store.intruderOn) { v -> Store.update { intruderOn = v } }
                    }
                    Spacer(Modifier.height(12.dp))
                    ALText("Capture after wrong attempts", size = 12, color = pal.sub)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (n in 1..5) Chip("$n", Store.intruderAttempts == n) { Store.update { intruderAttempts = n } }
                    }
                    if (!granted) {
                        Spacer(Modifier.height(12.dp))
                        GradientButton("Allow camera", Modifier.fillMaxWidth(), Icons.Rounded.PhotoCamera) {
                            camL.launch(Manifest.permission.CAMERA)
                        }
                    }
                }
            }
        }
        if (items.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column(Modifier.fillMaxWidth().padding(vertical = 36.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Rounded.PhotoCamera, null, tint = pal.accent, modifier = Modifier.size(64.dp))
                    Spacer(Modifier.height(10.dp))
                    ALText("No intruders yet", size = 18, weight = FontWeight.Bold)
                    ALText("Selfies of failed unlock attempts will appear here.", size = 13, color = pal.sub, align = TextAlign.Center)
                }
            }
        } else {
            itemsIndexed(items, key = { _, x -> x.file.name }) { i, x ->
                PhotoCard(x, i) { open = x }
            }
        }
    }
    val cur = open
    if (cur != null) {
        Dialog(onDismissRequest = { open = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Viewer(cur, onClose = { open = null }, onDelete = {
                Intruders.delete(cur)
                open = null
            })
        }
    }
}

@Composable
private fun rememberPhoto(x: Intruder, sample: Int): ImageBitmap? {
    val bmp by produceState<ImageBitmap?>(null, x.file.path, sample) {
        value = withContext(Dispatchers.IO) {
            val o = BitmapFactory.Options().apply { inSampleSize = sample }
            BitmapFactory.decodeFile(x.file.path, o)?.asImageBitmap()
        }
    }
    return bmp
}

@Composable
private fun PhotoCard(x: Intruder, idx: Int, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val pal = LocalPal.current
    val bmp = rememberPhoto(x, 2)
    var vis by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay((idx % 8) * 60L)
        vis = true
    }
    AnimatedVisibility(vis, enter = fadeIn(tween(400)) + scaleIn(spring(Spring.DampingRatioMediumBouncy), initialScale = 0.7f)) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(0.78f).bounceClick(onClick)
                .clip(RoundedCornerShape(22.dp)).background(pal.card).border(1.dp, pal.border, RoundedCornerShape(22.dp))
        ) {
            if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000))))
                    .padding(10.dp)
            ) {
                Column {
                    ALText(labelOf(ctx, x.pkg), size = 13, weight = FontWeight.Bold, color = Color.White, maxLines = 1)
                    ALText(fmt(x.time), size = 11, color = Color(0xCCFFFFFF))
                }
            }
        }
    }
}

@Composable
private fun Viewer(x: Intruder, onClose: () -> Unit, onDelete: () -> Unit) {
    val ctx = LocalContext.current
    val pal = LocalPal.current
    val bmp = rememberPhoto(x, 1)
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        Box(
            Modifier.align(Alignment.TopEnd).systemBarsPadding().padding(16.dp).size(44.dp)
                .clip(CircleShape).background(Color(0x66000000)).bounceClick(onClose),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.Close, null, tint = Color.White) }
        Row(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().systemBarsPadding().padding(16.dp)
                .clip(RoundedCornerShape(22.dp)).background(Color(0x99000000)).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                ALText("Tried to open ${labelOf(ctx, x.pkg)}", size = 15, weight = FontWeight.Bold, color = Color.White)
                ALText(fmt(x.time), size = 12, color = Color(0xCCFFFFFF))
            }
            Box(
                Modifier.bounceClick(onDelete).clip(RoundedCornerShape(14.dp)).background(pal.bad).padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Delete, null, tint = Color.White, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    ALText("Delete", size = 13, weight = FontWeight.Bold, color = Color.White)
                }
            }
        }
    }
}

// ---------------------------------------------------------------- STYLES

@Composable
private fun StylesTab() {
    val pal = LocalPal.current
    var preview by remember { mutableStateOf<String?>(null) }
    LazyVerticalGrid(
        GridCells.Fixed(2), Modifier.fillMaxSize(),
        contentPadding = PaddingValues(18.dp, 4.dp, 18.dp, 18.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column {
                ALText("Lock screen styles", size = 22, weight = FontWeight.Black)
                ALText("Tap to apply. Live styles animate on your lock screen.", size = 13, color = pal.sub)
            }
        }
        itemsIndexed(LockStyles) { i, st ->
            StyleCard(st, Store.lockStyle == st.id, i, onSelect = { Store.update { lockStyle = st.id } }, onPreview = { preview = st.id })
        }
    }
    val p = preview
    if (p != null) {
        Dialog(onDismissRequest = { preview = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            LockPreview(p) { preview = null }
        }
    }
}

@Composable
private fun StyleCard(st: LockStyle, selected: Boolean, idx: Int, onSelect: () -> Unit, onPreview: () -> Unit) {
    val pal = LocalPal.current
    val shape = RoundedCornerShape(22.dp)
    var vis by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay((idx % 6) * 70L)
        vis = true
    }
    val bc by animateColorAsState(if (selected) pal.accent else pal.border, tween(300), label = "sb")
    AnimatedVisibility(vis, enter = fadeIn(tween(450)) + scaleIn(spring(Spring.DampingRatioMediumBouncy), initialScale = 0.75f)) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(0.66f).bounceClick(onSelect)
                .clip(shape).border(if (selected) 3.dp else 1.dp, bc, shape)
        ) {
            LockBackground(st.id, pal.dark)
            val ink = styleInk(st.id, pal.dark)
            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Rounded.Lock, null, tint = ink, modifier = Modifier.size(28.dp))
                Spacer(Modifier.height(8.dp))
                PinDots(4, 2, ink, false, 0f)
            }
            Column(
                Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(10.dp)
            ) {
                ALText(st.name, size = 14, weight = FontWeight.Bold, color = ink, maxLines = 1)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ALText(if (st.live) "LIVE" else "STATIC", size = 10, weight = FontWeight.Bold, color = ink.copy(alpha = 0.75f))
                    Spacer(Modifier.weight(1f))
                    Box(
                        Modifier.clip(RoundedCornerShape(10.dp)).background(Color(0x55000000))
                            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onPreview)
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) { ALText("Preview", size = 11, color = Color.White) }
                }
            }
            if (selected) {
                Box(
                    Modifier.align(Alignment.TopEnd).padding(10.dp).size(26.dp).clip(CircleShape).background(pal.accent),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(16.dp)) }
            }
        }
    }
}

// ---------------------------------------------------------------- SETTINGS

@Composable
fun Section(title: String, content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    val pal = LocalPal.current
    Column(Modifier.fillMaxWidth()) {
        ALText(title.uppercase(), size = 11, weight = FontWeight.Bold, color = pal.sub, modifier = Modifier.padding(start = 6.dp, bottom = 6.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp), content = content)
        }
    }
}

@Composable
fun ToggleRow(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val pal = LocalPal.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 10.dp)) {
            ALText(title, size = 15, weight = FontWeight.SemiBold)
            ALText(desc, size = 12, color = pal.sub)
        }
        LockToggle(checked, onChange)
    }
}

@Composable
fun ChipRow(title: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val pal = LocalPal.current
    Column {
        ALText(title, size = 15, weight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEachIndexed { i, o -> Chip(o, selected == i) { onSelect(i) } }
        }
    }
}

@Composable
private fun SettingsTab(act: MainActivity) {
    val pal = LocalPal.current
    var creator by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Section("Security") {
            Row(
                Modifier.fillMaxWidth().bounceClick { creator = true },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    ALText("Change PIN / pattern", size = 15, weight = FontWeight.SemiBold)
                    ALText("Currently: ${if (Store.credType == "PATTERN") "Pattern" else "${Store.pinLen}-digit PIN"}", size = 12, color = pal.sub)
                }
                Icon(Icons.Rounded.Lock, null, tint = pal.accent)
            }
            ToggleRow("Biometric unlock", "Fingerprint or face on the lock screen", Store.biometric) { v -> Store.update { biometric = v } }
            ToggleRow("Shuffle keypad", "Randomise digit positions every time", Store.shuffle) { v -> Store.update { shuffle = v } }
            ToggleRow("Haptic feedback", "Vibrate on key press and wrong code", Store.haptics) { v -> Store.update { haptics = v } }
            ToggleRow("Hide pattern path", "Don't draw the line while unlocking", Store.hidePath) { v -> Store.update { hidePath = v } }
            ChipRow("Re-lock", listOf("Instantly", "After 1 min", "Screen off"), Store.relock) { i -> Store.update { relock = i } }
            ToggleRow("Fake crash disguise", "Locked apps first show an \"isn't responding\" box. Long-press Wait to reveal the real lock.", Store.fakeCrash) { v -> Store.update { fakeCrash = v } }
            DecoyRow()
            AdminRow(act)
        }
        Section("Intruder selfie") {
            ToggleRow("Capture intruders", "Front-camera photo after wrong attempts", Store.intruderOn) { v -> Store.update { intruderOn = v } }
            ChipRow("After wrong attempts", listOf("1", "2", "3", "4", "5"), Store.intruderAttempts - 1) { i -> Store.update { intruderAttempts = i + 1 } }
        }
        Section("Appearance") {
            ChipRow("Theme", listOf("System", "Light", "Dark"), Store.themeMode) { i -> Store.update { themeMode = i } }
            ChipRow("Unlock animation", listOf("Check", "Padlock", "Portal"), Store.unlockFx) { i -> Store.update { unlockFx = i } }
        }
        Build3Settings(act)
        Column {
            ALText("PERMISSIONS", size = 11, weight = FontWeight.Bold, color = pal.sub, modifier = Modifier.padding(start = 6.dp, bottom = 6.dp))
            PermissionsPanel(act)
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                ALText("App Lock Best  v1.3.0", size = 15, weight = FontWeight.Bold)
                ALText("100% native Kotlin + Jetpack Compose. Selfies and settings stay on your device only.", size = 12, color = pal.sub)
            }
        }
        Spacer(Modifier.height(10.dp))
    }
    if (creator) {
        Dialog(onDismissRequest = { creator = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Box(Modifier.fillMaxSize()) {
                LiveBackground()
                Box(Modifier.fillMaxSize().systemBarsPadding().padding(20.dp)) {
                    CredentialCreator(
                        onDone = { type, len, code ->
                            Cred.set(type, len, code)
                            creator = false
                        },
                        onCancel = { creator = false }
                    )
                }
            }
        }
    }
}
