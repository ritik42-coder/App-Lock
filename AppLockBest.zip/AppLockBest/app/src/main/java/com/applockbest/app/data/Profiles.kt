package com.applockbest.app.data

import java.util.Calendar

object Profiles {
    /** True when locking should currently be enforced (not paused, inside the schedule if one is set). */
    fun lockActive(): Boolean {
        if (System.currentTimeMillis() < Store.pauseUntil) return false
        if (Store.schedOn) {
            val cal = Calendar.getInstance()
            val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
            val s = Store.schedStart
            val e = Store.schedEnd
            if (s == e) return true
            val inside = if (s < e) (now >= s && now < e) else (now >= s || now < e)
            if (!inside) return false
        }
        return true
    }
}
