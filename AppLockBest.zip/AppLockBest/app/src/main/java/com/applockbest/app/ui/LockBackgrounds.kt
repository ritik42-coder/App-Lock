package com.applockbest.app.ui

import android.graphics.Typeface
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.random.Random

data class LockStyle(val id: String, val name: String, val live: Boolean)

val LockStyles = listOf(
    LockStyle("aurora", "Aurora Flow", true),
    LockStyle("neon", "Neon Grid", true),
    LockStyle("stars", "Hyperspace", true),
    LockStyle("matrix", "Code Rain", true),
    LockStyle("ocean", "Deep Ocean", true),
    LockStyle("liquid", "Liquid Glass", true),
    LockStyle("galaxy", "Particle Galaxy", true),
    LockStyle("cyber", "Cyber HUD", true),
    LockStyle("lava", "Lava Lamp", true),
    LockStyle("rain", "Rain on Glass", true),
    LockStyle("fireflies", "Fireflies", true),
    LockStyle("borealis", "Northern Lights", true),
    LockStyle("sakura", "Cherry Blossom", true),
    LockStyle("midnight", "Midnight", false),
    LockStyle("sunset", "Sunset Glow", false),
    LockStyle("glass", "Frost Glass", false)
)

fun styleInk(id: String, dark: Boolean): Color =
    if (id == "glass" && !dark) Color(0xFF16123A) else Color.White

private const val GLYPHS = "01ABCDEF<>/+*#%&=?"

@Composable
fun LockBackground(id: String, dark: Boolean, modifier: Modifier = Modifier) {
    val tr = rememberInfiniteTransition(label = "lockbg")
    val t by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(16000, easing = LinearEasing)), label = "t")
    val rnd = remember {
        val r = Random(11)
        List(120) { floatArrayOf(r.nextFloat(), r.nextFloat(), r.nextFloat()) }
    }
    val glyphs = remember { GLYPHS.toCharArray() }
    val paint = remember {
        android.graphics.Paint().apply {
            isAntiAlias = true
            typeface = Typeface.MONOSPACE
            textSize = 34f
            color = 0xFF22FF88.toInt()
        }
    }
    Canvas(modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val tau = 2f * PI.toFloat()
        fun blob(cx: Float, cy: Float, r: Float, c: Color) =
            drawCircle(Brush.radialGradient(listOf(c, Color.Transparent), Offset(cx, cy), r), r, Offset(cx, cy))

        when (id) {
            "aurora" -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF050818), Color(0xFF0B1235), Color(0xFF14083A))))
                val a = t * tau
                blob(w * (0.25f + 0.25f * sin(a)), h * (0.25f + 0.10f * cos(a * 2f)), w * 0.9f, Color(0xFF22D3EE).copy(alpha = 0.45f))
                blob(w * (0.75f + 0.20f * cos(a)), h * (0.45f + 0.12f * sin(a)), w, Color(0xFF8B5CF6).copy(alpha = 0.50f))
                blob(w * (0.5f + 0.30f * sin(a + 1.5f)), h * (0.80f + 0.08f * cos(a)), w, Color(0xFF34D399).copy(alpha = 0.28f))
                for (k in 0..2) {
                    val base = h * (0.22f + 0.16f * k)
                    val p = Path()
                    var x = 0f
                    p.moveTo(0f, base)
                    while (x <= w) {
                        p.lineTo(x, base + 38f * sin(x / w * tau * (1 + k) + a * (k + 1)))
                        x += 24f
                    }
                    drawPath(p, Color.White.copy(alpha = 0.10f), style = Stroke(70f, cap = StrokeCap.Round))
                }
            }

            "neon" -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF0A0018), Color(0xFF2A0A4A), Color(0xFF0A0018))))
                val hy = h * 0.52f
                drawCircle(
                    Brush.verticalGradient(listOf(Color(0xFFFFD166), Color(0xFFFF3D8B)), startY = hy - w * 0.35f, endY = hy),
                    w * 0.30f, Offset(w / 2f, hy - w * 0.05f)
                )
                drawRect(Color(0xFF0A0018), Offset(0f, hy), androidx.compose.ui.geometry.Size(w, h - hy))
                val step = 1f / 14f
                for (i in 0 until 14) {
                    val q = (i * step + t * 8f * step) % 1f
                    val y = hy + (h - hy) * q * q
                    drawLine(Color(0xFFFF3DDB).copy(alpha = 0.15f + 0.7f * q), Offset(0f, y), Offset(w, y), 1.5f + 2f * q)
                }
                for (k in -10..10) {
                    drawLine(
                        Color(0xFF22D3EE).copy(alpha = 0.45f),
                        Offset(w / 2f + k * w * 0.02f, hy), Offset(w / 2f + k * w * 0.20f, h), 2f
                    )
                }
            }

            "stars" -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF02030A), Color(0xFF0A1030))))
                val cx = w / 2f
                val cy = h * 0.42f
                val maxR = hypot(w, h) / 2f
                for ((idx, s) in rnd.withIndex()) {
                    val ang = s[0] * tau
                    val d = (s[1] + t * (idx % 3 + 1)) % 1f
                    val d0 = (d - 0.05f * (0.4f + s[2])).coerceAtLeast(0f)
                    drawLine(
                        Color(0xFFBFD4FF).copy(alpha = (0.15f + 0.85f * d).coerceIn(0f, 1f)),
                        Offset(cx + cos(ang) * d0 * maxR, cy + sin(ang) * d0 * maxR),
                        Offset(cx + cos(ang) * d * maxR, cy + sin(ang) * d * maxR),
                        1f + 2.5f * d, StrokeCap.Round
                    )
                }
            }

            "matrix" -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF000604), Color(0xFF001A0E))))
                val cols = (w / 30f).toInt()
                val trail = 14
                for (c in 0 until cols) {
                    val seed = ((c * 37) % 100) / 100f
                    val cycles = 1 + c % 3
                    val head = ((seed + t * cycles) % 1f) * (h + trail * 34f)
                    for (j in 0 until trail) {
                        val y = head - j * 34f
                        if (y < 0f || y > h) continue
                        val a = 1f - j / trail.toFloat()
                        paint.color = if (j == 0) 0xFFE8FFF0.toInt() else 0xFF22FF88.toInt()
                        paint.alpha = (255 * a * 0.9f).toInt()
                        val gi = (c * 7 + j * 3 + (t * 60f).toInt()) % glyphs.size
                        drawIntoCanvas { it.nativeCanvas.drawText(glyphs, gi, 1, c * 30f + 4f, y, paint) }
                    }
                }
            }

            "ocean" -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF021B3A), Color(0xFF05407A), Color(0xFF0A6AA8))))
                val a = t * tau
                for (b in 0 until 14) {
                    val s = rnd[b]
                    val y = h - ((s[1] + t * (1 + b % 2)) % 1f) * h
                    drawCircle(Color.White.copy(alpha = 0.18f), 4f + s[2] * 12f, Offset(s[0] * w + sin(a + s[2] * 6f) * 14f, y), style = Stroke(2f))
                }
                for (k in 0..3) {
                    val base = h * (0.58f + 0.1f * k)
                    val p = Path()
                    p.moveTo(0f, h)
                    var x = 0f
                    while (x <= w + 20f) {
                        p.lineTo(x, base + (18f + 8f * k) * sin(x / w * tau * (1 + k % 2) + a * (k + 1) * (if (k % 2 == 0) 1 else -1)))
                        x += 20f
                    }
                    p.lineTo(w, h)
                    p.close()
                    drawPath(p, Color(0xFF38BDF8).copy(alpha = 0.16f + 0.06f * k))
                }
            }

            "liquid" -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF0B1030), Color(0xFF1B1058), Color(0xFF0A2A4A))))
                val a = t * tau
                val cols = listOf(Color(0xFFFF4FA3), Color(0xFF22D3EE), Color(0xFF8B5CF6), Color(0xFFFFB84D), Color(0xFF34D399))
                for (k in 0 until 5) {
                    val s = rnd[k]
                    blob(
                        w * (0.5f + 0.38f * sin(a * (1 + k % 2) + s[0] * 6f)),
                        h * (0.5f + 0.38f * cos(a * (1 + (k + 1) % 2) + s[1] * 6f)),
                        w * 0.62f, cols[k].copy(alpha = 0.55f)
                    )
                }
                val lx = w * (0.5f + 0.18f * sin(a))
                val ly = h * (0.34f + 0.06f * cos(a * 2f))
                val lr = w * 0.24f
                drawCircle(Color.White.copy(alpha = 0.10f), lr, Offset(lx, ly))
                drawCircle(Color.White.copy(alpha = 0.35f), lr, Offset(lx, ly), style = Stroke(2.5f))
                drawArc(
                    color = Color.White.copy(alpha = 0.55f), startAngle = 200f, sweepAngle = 70f, useCenter = false,
                    topLeft = Offset(lx - lr * 0.86f, ly - lr * 0.86f), size = Size(lr * 1.72f, lr * 1.72f),
                    style = Stroke(5f, cap = StrokeCap.Round)
                )
            }

            "galaxy" -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF02020A), Color(0xFF0A0620))))
                val cx = w / 2f
                val cy = h * 0.40f
                val maxR = w * 0.62f
                blob(cx, cy, maxR, Color(0xFF7C5CFF).copy(alpha = 0.25f))
                blob(cx, cy, maxR * 0.25f, Color(0xFFFFE7B0).copy(alpha = 0.5f))
                for (i in 0 until 120) {
                    val s = rnd[i]
                    val r = (0.08f + 0.92f * s[1]) * maxR
                    val ang = (i % 3) * 2.094f + (r / maxR) * 5f + t * tau + s[2] * 0.6f
                    val x = cx + cos(ang) * r
                    val y = cy + sin(ang) * r * 0.62f
                    val tw = 0.5f + 0.5f * sin(t * tau * 3f + s[0] * 6f)
                    val col = if (s[2] > 0.6f) Color(0xFF9BE7FF) else if (s[2] > 0.3f) Color(0xFFFFFFFF) else Color(0xFFFF9ADF)
                    drawCircle(col.copy(alpha = 0.35f + 0.6f * tw), 1.2f + s[2] * 2.6f, Offset(x, y))
                }
            }

            "cyber" -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF020B14), Color(0xFF04212E), Color(0xFF020B14))))
                val cx = w / 2f
                val cy = h * 0.34f
                val cyan = Color(0xFF22E5FF)
                for (k in 0..2) {
                    val r = w * (0.20f + 0.09f * k)
                    val dir = if (k % 2 == 0) 1f else -1f
                    for (q in 0..2) {
                        drawArc(
                            color = cyan.copy(alpha = 0.7f - 0.15f * k),
                            startAngle = dir * t * 360f * (k + 1) + q * 120f, sweepAngle = 70f, useCenter = false,
                            topLeft = Offset(cx - r, cy - r), size = Size(r * 2f, r * 2f),
                            style = Stroke(4f + 2f * (2 - k), cap = StrokeCap.Round)
                        )
                    }
                    drawCircle(cyan.copy(alpha = 0.10f), r, Offset(cx, cy), style = Stroke(1.5f))
                }
                val sy = ((t * 2f) % 1f) * h
                drawRect(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, cyan.copy(alpha = 0.25f), Color.Transparent),
                        startY = sy - 60f, endY = sy + 60f
                    ),
                    Offset(0f, sy - 60f), Size(w, 120f)
                )
                val m = 26f
                val ln = 60f
                val bc = cyan.copy(alpha = 0.8f)
                drawLine(bc, Offset(m, m), Offset(m + ln, m), 4f)
                drawLine(bc, Offset(m, m), Offset(m, m + ln), 4f)
                drawLine(bc, Offset(w - m, m), Offset(w - m - ln, m), 4f)
                drawLine(bc, Offset(w - m, m), Offset(w - m, m + ln), 4f)
                drawLine(bc, Offset(m, h - m), Offset(m + ln, h - m), 4f)
                drawLine(bc, Offset(m, h - m), Offset(m, h - m - ln), 4f)
                drawLine(bc, Offset(w - m, h - m), Offset(w - m - ln, h - m), 4f)
                drawLine(bc, Offset(w - m, h - m), Offset(w - m, h - m - ln), 4f)
            }

            "lava" -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF1A0524), Color(0xFF3B0A2E), Color(0xFF12041C))))
                val a = t * tau
                val cols = listOf(
                    Color(0xFFFF7A18), Color(0xFFFF3D77), Color(0xFFFFC857),
                    Color(0xFFFF5E3A), Color(0xFFD946EF), Color(0xFFFF9A3C)
                )
                for (k in 0 until 6) {
                    val s = rnd[k + 10]
                    val x = w * (0.5f + 0.34f * sin(a * (1 + k % 2) + s[0] * 6f))
                    val y = h * (0.5f + 0.42f * cos(a * (1 + (k + 1) % 2) + s[1] * 6f))
                    blob(x, y, w * (0.30f + 0.12f * s[2]), cols[k].copy(alpha = 0.85f))
                }
            }

            "rain" -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF0B1220), Color(0xFF1B2A41), Color(0xFF0E1726))))
                blob(w * 0.3f, h * 0.2f, w * 0.7f, Color(0xFF4F7CFF).copy(alpha = 0.18f))
                for (i in 0 until 70) {
                    val s = rnd[i]
                    val y = ((s[1] + t * (1 + i % 3)) % 1f) * (h + 80f) - 40f
                    val x = s[0] * w
                    drawLine(
                        Color(0xFFBFD8FF).copy(alpha = 0.10f + 0.25f * s[2]),
                        Offset(x, y), Offset(x - 4f, y + 30f + s[2] * 50f), 1.5f + s[2] * 1.5f, StrokeCap.Round
                    )
                }
                for (i in 70 until 100) {
                    val s = rnd[i]
                    val al = 0.5f + 0.5f * sin(t * tau + s[2] * 6f)
                    val c = Offset(s[0] * w, s[1] * h)
                    drawCircle(Color.White.copy(alpha = 0.10f * al), 7f + s[2] * 9f, c)
                    drawCircle(Color.White.copy(alpha = 0.35f * al), 7f + s[2] * 9f, c, style = Stroke(1.5f))
                }
            }

            "fireflies" -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF020A06), Color(0xFF0A1F12), Color(0xFF02100A))))
                val a = t * tau
                for (i in 0 until 44) {
                    val s = rnd[i]
                    val x = (s[0] + 0.05f * sin(a * (1 + i % 2) + s[2] * 6f)) * w
                    val y = (((s[1] - t * (1 + i % 2)) % 1f) + 1f) % 1f * h
                    val pulse = 0.5f + 0.5f * sin(a * 3f + s[2] * 6f)
                    val r = 16f + 14f * s[2]
                    drawCircle(
                        Brush.radialGradient(
                            listOf(Color(0xFFD6FF5C).copy(alpha = 0.15f + 0.6f * pulse), Color.Transparent),
                            Offset(x, y), r * 2.2f
                        ),
                        r * 2.2f, Offset(x, y)
                    )
                    drawCircle(Color(0xFFF4FFC2).copy(alpha = 0.4f + 0.6f * pulse), 2.5f, Offset(x, y))
                }
            }

            "borealis" -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF01030D), Color(0xFF07122B), Color(0xFF0B2A3D))))
                val a = t * tau
                val cc = listOf(Color(0xFF34F5A0), Color(0xFF22D3EE), Color(0xFF8B5CF6), Color(0xFF34F5A0))
                for (k in 0..3) {
                    var x = 0f
                    while (x <= w) {
                        val st = 0.5f + 0.5f * sin(x / w * tau * (k + 2) + a * (1 + k % 2) + k)
                        val top = h * (0.08f + 0.05f * k)
                        drawLine(cc[k].copy(alpha = 0.06f + 0.22f * st), Offset(x, top), Offset(x, top + h * 0.30f * (0.4f + st)), 16f)
                        x += 14f
                    }
                }
                val m = Path()
                m.moveTo(0f, h)
                m.lineTo(0f, h * 0.84f)
                m.lineTo(w * 0.18f, h * 0.76f)
                m.lineTo(w * 0.34f, h * 0.86f)
                m.lineTo(w * 0.52f, h * 0.72f)
                m.lineTo(w * 0.70f, h * 0.85f)
                m.lineTo(w * 0.86f, h * 0.77f)
                m.lineTo(w, h * 0.86f)
                m.lineTo(w, h)
                m.close()
                drawPath(m, Color(0xFF02060E))
            }

            "sakura" -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF1E0B33), Color(0xFF5B2A5E), Color(0xFFD9667E))))
                drawCircle(Color(0xFFFFE0D0).copy(alpha = 0.85f), w * 0.14f, Offset(w * 0.78f, h * 0.2f))
                blob(w * 0.78f, h * 0.2f, w * 0.5f, Color(0xFFFFB3C7).copy(alpha = 0.25f))
                val a = t * tau
                for (i in 0 until 40) {
                    val s = rnd[i]
                    val y = ((s[1] + t * (1 + i % 2)) % 1f) * (h + 60f) - 30f
                    val x = s[0] * w + sin(a * (1 + i % 2) + s[2] * 6f) * 34f
                    val pw = 12f + s[2] * 12f
                    rotate(t * 360f * (1 + i % 2) + s[0] * 360f, Offset(x, y)) {
                        drawOval(Color(0xFFFFC2D6).copy(alpha = 0.85f), Offset(x - pw / 2f, y - pw * 0.3f), Size(pw, pw * 0.6f))
                    }
                }
            }

            "midnight" -> {
                drawRect(Color.Black)
                blob(w / 2f, h * 0.18f, w * 0.9f, Color(0xFF6D4AFF).copy(alpha = 0.28f))
                blob(w / 2f, h * 1.0f, w, Color(0xFF22D3EE).copy(alpha = 0.10f))
            }

            "sunset" -> {
                drawRect(
                    Brush.verticalGradient(
                        listOf(Color(0xFF1B1036), Color(0xFF6B2D8F), Color(0xFFFF5E7E), Color(0xFFFFB86B))
                    )
                )
                drawCircle(Color(0xFFFFE29A).copy(alpha = 0.9f), w * 0.28f, Offset(w / 2f, h * 0.78f))
                blob(w / 2f, h * 0.78f, w * 0.8f, Color(0xFFFFB86B).copy(alpha = 0.35f))
            }

            else -> { // glass
                if (dark) {
                    drawRect(Brush.verticalGradient(listOf(Color(0xFF101830), Color(0xFF1D2B53))))
                    blob(w * 0.2f, h * 0.2f, w * 0.7f, Color(0xFF7C5CFF).copy(alpha = 0.35f))
                    blob(w * 0.85f, h * 0.7f, w * 0.7f, Color(0xFF22D3EE).copy(alpha = 0.25f))
                } else {
                    drawRect(Brush.verticalGradient(listOf(Color(0xFFF4F1FF), Color(0xFFDDEBFF))))
                    blob(w * 0.2f, h * 0.2f, w * 0.7f, Color(0xFF8B6CFF).copy(alpha = 0.30f))
                    blob(w * 0.85f, h * 0.7f, w * 0.7f, Color(0xFF38BDF8).copy(alpha = 0.30f))
                }
            }
        }
        if (!(id == "glass" && !dark)) {
            drawRect(
                Brush.verticalGradient(listOf(Color.Transparent, Color(0x66000000)), startY = h * 0.4f, endY = h)
            )
        }
    }
}
