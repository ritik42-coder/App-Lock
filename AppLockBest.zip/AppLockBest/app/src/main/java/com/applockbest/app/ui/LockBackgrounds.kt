package com.applockbest.app.ui

import android.graphics.Typeface
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.random.Random

data class LockStyle(val id: String, val name: String, val live: Boolean)

val LockStyles = listOf(
    LockStyle("aurora", "Aurora Flow", true),
    LockStyle("neon", "Neon Grid", true),
    LockStyle("stars", "Hyperspace", true),
    LockStyle("matrix", "Code Rain", true),
    LockStyle("ocean", "Deep Ocean", true),
    LockStyle("midnight", "Midnight", false),
    LockStyle("sunset", "Sunset Glow", false),
    LockStyle("glass", "Frost Glass", false)
)

fun styleInk(id: String, dark: Boolean): Color =
    if (id == "glass" && !dark) Color(0xFF16123A) else Color.White

private const val GLYPHS = "01ABCDEF<>/+*#%&=?"

@Composable
fun LockBackground(id: String, dark: Boolean, modifier: Modifier = Modifier) {
    val tr = rememberInfiniteTransition(label = "lockbg")
    val t by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(16000, easing = LinearEasing)), label = "t")
    val rnd = remember {
        val r = Random(11)
        List(120) { floatArrayOf(r.nextFloat(), r.nextFloat(), r.nextFloat()) }
    }
    val glyphs = remember { GLYPHS.toCharArray() }
    val paint = remember {
        android.graphics.Paint().apply {
            isAntiAlias = true
            typeface = Typeface.MONOSPACE
            textSize = 34f
            color = 0xFF22FF88.toInt()
        }
    }
    Canvas(modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val tau = 2f * PI.toFloat()
        fun blob(cx: Float, cy: Float, r: Float, c: Color) =
            drawCircle(Brush.radialGradient(listOf(c, Color.Transparent), Offset(cx, cy), r), r, Offset(cx, cy))

        when (id) {
            "aurora" -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF050818), Color(0xFF0B1235), Color(0xFF14083A))))
                val a = t * tau
                blob(w * (0.25f + 0.25f * sin(a)), h * (0.25f + 0.10f * cos(a * 2f)), w * 0.9f, Color(0xFF22D3EE).copy(alpha = 0.45f))
                blob(w * (0.75f + 0.20f * cos(a)), h * (0.45f + 0.12f * sin(a)), w, Color(0xFF8B5CF6).copy(alpha = 0.50f))
                blob(w * (0.5f + 0.30f * sin(a + 1.5f)), h * (0.80f + 0.08f * cos(a)), w, Color(0xFF34D399).copy(alpha = 0.28f))
                for (k in 0..2) {
                    val base = h * (0.22f + 0.16f * k)
                    val p = Path()
                    var x = 0f
                    p.moveTo(0f, base)
                    while (x <= w) {
                        p.lineTo(x, base + 38f * sin(x / w * tau * (1 + k) + a * (k + 1)))
                        x += 24f
                    }
                    drawPath(p, Color.White.copy(alpha = 0.10f), style = Stroke(70f, cap = StrokeCap.Round))
                }
            }

            "neon" -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF0A0018), Color(0xFF2A0A4A), Color(0xFF0A0018))))
                val hy = h * 0.52f
                drawCircle(
                    Brush.verticalGradient(listOf(Color(0xFFFFD166), Color(0xFFFF3D8B)), startY = hy - w * 0.35f, endY = hy),
                    w * 0.30f, Offset(w / 2f, hy - w * 0.05f)
                )
                drawRect(Color(0xFF0A0018), Offset(0f, hy), androidx.compose.ui.geometry.Size(w, h - hy))
                val step = 1f / 14f
                for (i in 0 until 14) {
                    val q = (i * step + t * 8f * step) % 1f
                    val y = hy + (h - hy) * q * q
                    drawLine(Color(0xFFFF3DDB).copy(alpha = 0.15f + 0.7f * q), Offset(0f, y), Offset(w, y), 1.5f + 2f * q)
                }
                for (k in -10..10) {
                    drawLine(
                        Color(0xFF22D3EE).copy(alpha = 0.45f),
                        Offset(w / 2f + k * w * 0.02f, hy), Offset(w / 2f + k * w * 0.20f, h), 2f
                    )
                }
            }

            "stars" -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF02030A), Color(0xFF0A1030))))
                val cx = w / 2f
                val cy = h * 0.42f
                val maxR = hypot(w, h) / 2f
                for ((idx, s) in rnd.withIndex()) {
                    val ang = s[0] * tau
                    val d = (s[1] + t * (idx % 3 + 1)) % 1f
                    val d0 = (d - 0.05f * (0.4f + s[2])).coerceAtLeast(0f)
                    drawLine(
                        Color(0xFFBFD4FF).copy(alpha = (0.15f + 0.85f * d).coerceIn(0f, 1f)),
                        Offset(cx + cos(ang) * d0 * maxR, cy + sin(ang) * d0 * maxR),
                        Offset(cx + cos(ang) * d * maxR, cy + sin(ang) * d * maxR),
                        1f + 2.5f * d, StrokeCap.Round
                    )
                }
            }

            "matrix" -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF000604), Color(0xFF001A0E))))
                val cols = (w / 30f).toInt()
                val trail = 14
                for (c in 0 until cols) {
                    val seed = ((c * 37) % 100) / 100f
                    val cycles = 1 + c % 3
                    val head = ((seed + t * cycles) % 1f) * (h + trail * 34f)
                    for (j in 0 until trail) {
                        val y = head - j * 34f
                        if (y < 0f || y > h) continue
                        val a = 1f - j / trail.toFloat()
                        paint.color = if (j == 0) 0xFFE8FFF0.toInt() else 0xFF22FF88.toInt()
                        paint.alpha = (255 * a * 0.9f).toInt()
                        val gi = (c * 7 + j * 3 + (t * 60f).toInt()) % glyphs.size
                        drawIntoCanvas { it.nativeCanvas.drawText(glyphs, gi, 1, c * 30f + 4f, y, paint) }
                    }
                }
            }

            "ocean" -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF021B3A), Color(0xFF05407A), Color(0xFF0A6AA8))))
                val a = t * tau
                for (b in 0 until 14) {
                    val s = rnd[b]
                    val y = h - ((s[1] + t * (1 + b % 2)) % 1f) * h
                    drawCircle(Color.White.copy(alpha = 0.18f), 4f + s[2] * 12f, Offset(s[0] * w + sin(a + s[2] * 6f) * 14f, y), style = Stroke(2f))
                }
                for (k in 0..3) {
                    val base = h * (0.58f + 0.1f * k)
                    val p = Path()
                    p.moveTo(0f, h)
                    var x = 0f
                    while (x <= w + 20f) {
                        p.lineTo(x, base + (18f + 8f * k) * sin(x / w * tau * (1 + k % 2) + a * (k + 1) * (if (k % 2 == 0) 1 else -1)))
                        x += 20f
                    }
                    p.lineTo(w, h)
                    p.close()
                    drawPath(p, Color(0xFF38BDF8).copy(alpha = 0.16f + 0.06f * k))
                }
            }

            "midnight" -> {
                drawRect(Color.Black)
                blob(w / 2f, h * 0.18f, w * 0.9f, Color(0xFF6D4AFF).copy(alpha = 0.28f))
                blob(w / 2f, h * 1.0f, w, Color(0xFF22D3EE).copy(alpha = 0.10f))
            }

            "sunset" -> {
                drawRect(
                    Brush.verticalGradient(
                        listOf(Color(0xFF1B1036), Color(0xFF6B2D8F), Color(0xFFFF5E7E), Color(0xFFFFB86B))
                    )
                )
                drawCircle(Color(0xFFFFE29A).copy(alpha = 0.9f), w * 0.28f, Offset(w / 2f, h * 0.78f))
                blob(w / 2f, h * 0.78f, w * 0.8f, Color(0xFFFFB86B).copy(alpha = 0.35f))
            }

            else -> { // glass
                if (dark) {
                    drawRect(Brush.verticalGradient(listOf(Color(0xFF101830), Color(0xFF1D2B53))))
                    blob(w * 0.2f, h * 0.2f, w * 0.7f, Color(0xFF7C5CFF).copy(alpha = 0.35f))
                    blob(w * 0.85f, h * 0.7f, w * 0.7f, Color(0xFF22D3EE).copy(alpha = 0.25f))
                } else {
                    drawRect(Brush.verticalGradient(listOf(Color(0xFFF4F1FF), Color(0xFFDDEBFF))))
                    blob(w * 0.2f, h * 0.2f, w * 0.7f, Color(0xFF8B6CFF).copy(alpha = 0.30f))
                    blob(w * 0.85f, h * 0.7f, w * 0.7f, Color(0xFF38BDF8).copy(alpha = 0.30f))
                }
            }
        }
        if (!(id == "glass" && !dark)) {
            drawRect(
                Brush.verticalGradient(listOf(Color.Transparent, Color(0x66000000)), startY = h * 0.4f, endY = h)
            )
        }
    }
}
