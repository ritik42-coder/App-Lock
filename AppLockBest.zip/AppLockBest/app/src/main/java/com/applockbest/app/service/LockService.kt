package com.applockbest.app.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.applockbest.app.LockActivity
import com.applockbest.app.MainActivity
import com.applockbest.app.R
import com.applockbest.app.data.Notifier
import com.applockbest.app.data.Perms
import com.applockbest.app.data.Store
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

class LockService : Service() {

    companion object {
        val unlocked = ConcurrentHashMap<String, Long>()

        fun unlock(pkg: String) {
            unlocked[pkg] = SystemClock.elapsedRealtime()
        }

        fun start(c: Context) {
            ContextCompat.startForegroundService(c, Intent(c, LockService::class.java))
        }

        fun stop(c: Context) {
            c.stopService(Intent(c, LockService::class.java))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private var current: String? = null
    private var lastLaunch = 0L

    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (Store.relock == 2) unlocked.clear()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        Notifier.channels(this)
        ContextCompat.registerReceiver(
            this, screenOff, IntentFilter(Intent.ACTION_SCREEN_OFF), ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
        if (job?.isActive != true) {
            job = scope.launch {
                while (isActive) {
                    try {
                        tick()
                    } catch (e: Throwable) {
                    }
                    delay(300)
                }
            }
        }
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, Notifier.CH_SERVICE)
            .setSmallIcon(R.drawable.ic_stat_lock)
            .setContentTitle("App Lock Best is protecting your apps")
            .setContentText("${Store.lockedApps.size} apps locked")
            .setOngoing(true)
            .setContentIntent(pi)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
    }

    private fun poll() {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val from = if (current == null) now - 3_600_000L else now - 2_500L
        val ev = usm.queryEvents(from, now)
        val e = UsageEvents.Event()
        var last: String? = null
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) last = e.packageName
        }
        if (last != null) current = last
    }

    private fun tick() {
        if (!Perms.usage(this)) return
        poll()
        val cur = current ?: return
        if (cur == packageName) return
        val now = SystemClock.elapsedRealtime()

        val it = unlocked.entries.iterator()
        while (it.hasNext()) {
            val en = it.next()
            if (en.key == cur) {
                en.setValue(now)
            } else {
                when (Store.relock) {
                    0 -> it.remove()
                    1 -> if (now - en.value > 60_000L) it.remove()
                }
            }
        }

        if (cur in Store.lockedApps && !unlocked.containsKey(cur)) {
            if (now - lastLaunch > 1200L) {
                lastLaunch = now
                launchLock(cur)
            }
        }
    }

    private fun launchLock(pkg: String) {
        val i = Intent(this, LockActivity::class.java)
            .putExtra("pkg", pkg)
            .addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_NO_ANIMATION
            )
        startActivity(i)
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(screenOff)
        } catch (e: Exception) {
        }
        scope.cancel()
        super.onDestroy()
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Store.init(c)
        if (Store.serviceOn && Perms.usage(c) && Perms.overlay(c)) {
            try {
                LockService.start(c)
            } catch (e: Exception) {
            }
        }
    }
}
