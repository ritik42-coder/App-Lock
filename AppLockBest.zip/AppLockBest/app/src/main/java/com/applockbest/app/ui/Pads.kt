package com.applockbest.app.ui

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.applockbest.app.data.Store
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private val BAD = Color(0xFFFF5C7A)

@Composable
fun PinDots(total: Int, filled: Int, ink: Color, error: Boolean, shake: Float) {
    Row(
        Modifier.offset { IntOffset(shake.roundToInt(), 0) },
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        repeat(total) { i ->
            val on = i < filled
            val s by animateFloatAsState(
                if (on) 1f else 0f, spring(Spring.DampingRatioMediumBouncy), label = "dot"
            )
            Box(
                Modifier
                    .size(16.dp)
                    .graphicsLayer { scaleX = 1f + 0.3f * s; scaleY = scaleX }
                    .clip(CircleShape)
                    .border(1.5.dp, if (error) BAD else ink.copy(alpha = 0.85f), CircleShape)
                    .background(if (on) (if (error) BAD else ink) else Color.Transparent)
            )
        }
    }
}

@Composable
private fun Key(
    label: String?, ink: Color, enabled: Boolean, onClick: () -> Unit,
    content: (@Composable () -> Unit)? = null
) {
    val haptic = LocalHapticFeedback.current
    Box(
        Modifier
            .size(68.dp)
            .bounceClick {
                if (enabled) {
                    if (Store.haptics) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onClick()
                }
            }
            .clip(CircleShape)
            .background(ink.copy(alpha = 0.10f))
            .border(1.dp, ink.copy(alpha = 0.18f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        if (label != null) ALText(label, size = 26, weight = FontWeight.Medium, color = ink)
        content?.invoke()
    }
}

@Composable
fun PinPad(
    ink: Color, shuffle: Boolean, shuffleKey: Int, enabled: Boolean,
    onDigit: (Char) -> Unit, onDelete: () -> Unit, onBiometric: (() -> Unit)?
) {
    val digits = remember(shuffle, shuffleKey) {
        if (shuffle) ('0'..'9').shuffled() else "1234567890".toList()
    }
    Column(verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        for (r in 0 until 3) {
            Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                for (c in 0 until 3) {
                    val d = digits[r * 3 + c]
                    Key(d.toString(), ink, enabled, { onDigit(d) })
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) {
            if (onBiometric != null) {
                Key(null, ink, enabled, { onBiometric() }) {
                    Icon(Icons.Rounded.Fingerprint, null, tint = ink, modifier = Modifier.size(30.dp))
                }
            } else {
                Box(Modifier.size(68.dp))
            }
            Key(digits[9].toString(), ink, enabled, { onDigit(digits[9]) })
            Key("⌫", ink, enabled, { onDelete() })
        }
    }
}

@Composable
fun PatternPad(
    modifier: Modifier = Modifier, ink: Color, accent: Color,
    hidePath: Boolean, error: Boolean, onDone: (String) -> Unit
) {
    val nodes = remember { mutableStateListOf<Int>() }
    var cur by remember { mutableStateOf<Offset?>(null) }
    val scope = rememberCoroutineScope()
    val gen = remember { intArrayOf(0) }
    val done by rememberUpdatedState(onDone)
    val col = if (error) BAD else accent

    Canvas(
        modifier
            .aspectRatio(1f)
            .pointerInput(Unit) {
                fun center(i: Int): Offset {
                    val cell = size.width / 3f
                    return Offset(cell * (i % 3 + 0.5f), cell * (i / 3 + 0.5f))
                }

                fun hit(p: Offset): Int? {
                    val cell = size.width / 3f
                    for (i in 0..8) if ((center(i) - p).getDistance() < cell * 0.34f) return i
                    return null
                }
                detectDragGestures(
                    onDragStart = { o ->
                        gen[0]++
                        nodes.clear()
                        cur = o
                        val h = hit(o)
                        if (h != null) nodes.add(h)
                    },
                    onDrag = { change, _ ->
                        change.consume()
                        cur = change.position
                        val h = hit(change.position)
                        if (h != null && h !in nodes) nodes.add(h)
                    },
                    onDragEnd = {
                        cur = null
                        val r = nodes.joinToString("")
                        val g = gen[0]
                        if (r.isNotEmpty()) done(r)
                        scope.launch {
                            delay(500)
                            if (gen[0] == g) nodes.clear()
                        }
                    },
                    onDragCancel = {
                        cur = null
                        nodes.clear()
                    }
                )
            }
    ) {
        val cell = size.width / 3f
        fun c(i: Int) = Offset(cell * (i % 3 + 0.5f), cell * (i / 3 + 0.5f))
        if (!hidePath && nodes.isNotEmpty()) {
            for (k in 0 until nodes.size - 1) {
                drawLine(col.copy(alpha = 0.9f), c(nodes[k]), c(nodes[k + 1]), 8.dp.toPx(), StrokeCap.Round)
            }
            val cc = cur
            if (cc != null) drawLine(col.copy(alpha = 0.5f), c(nodes.last()), cc, 6.dp.toPx(), StrokeCap.Round)
        }
        for (i in 0..8) {
            val on = i in nodes
            val ctr = c(i)
            drawCircle(if (on) col else ink.copy(alpha = 0.55f), if (on) 11.dp.toPx() else 7.dp.toPx(), ctr)
            if (on) drawCircle(col.copy(alpha = 0.25f), 26.dp.toPx(), ctr)
            else drawCircle(ink.copy(alpha = 0.12f), 24.dp.toPx(), ctr, style = Stroke(1.dp.toPx()))
        }
    }
}
