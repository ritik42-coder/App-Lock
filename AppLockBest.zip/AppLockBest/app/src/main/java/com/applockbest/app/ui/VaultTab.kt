package com.applockbest.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.applockbest.app.data.Store
import com.applockbest.app.data.Vault
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun VaultTab() {
    val ctx = LocalContext.current
    val pal = LocalPal.current
    val scope = rememberCoroutineScope()
    var msg by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var open by remember { mutableStateOf<Vault.Item?>(null) }
    val items = remember(Store.vaultTick, Store.decoyActive) {
        if (Store.decoyActive) emptyList<Vault.Item>() else Vault.list(ctx)
    }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            busy = true
            scope.launch {
                val n = withContext(Dispatchers.IO) { uris.count { Vault.add(ctx, it) } }
                busy = false
                msg = "Encrypted $n of ${uris.size} file(s). Your original copies were NOT deleted."
                Store.vaultTick = Store.vaultTick + 1
            }
        }
    }

    LazyVerticalGrid(
        GridCells.Fixed(2), Modifier.fillMaxSize(),
        contentPadding = PaddingValues(18.dp, 4.dp, 18.dp, 18.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            GlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    ALText("Encrypted vault", size = 20, weight = FontWeight.Black)
                    ALText("AES-256-GCM. The key is held by the Android Keystore.", size = 12, color = pal.sub)
                    Spacer(Modifier.height(12.dp))
                    if (!Store.decoyActive) {
                        GradientButton(if (busy) "Encrypting..." else "Add files", Modifier.fillMaxWidth(), Icons.Rounded.Add) {
                            if (!busy) pick.launch(arrayOf("*/*"))
                        }
                    }
                    val m = msg
                    if (m != null) {
                        Spacer(Modifier.height(8.dp))
                        ALText(m, size = 12, color = pal.good)
                    }
                    Spacer(Modifier.height(8.dp))
                    ALText(
                        "Original files stay where they are until you delete them yourself. Uninstalling the app erases the vault and its key for good.",
                        size = 11, color = pal.sub
                    )
                }
            }
        }
        if (items.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column(Modifier.fillMaxWidth().padding(vertical = 36.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Rounded.Folder, null, tint = pal.accent, modifier = Modifier.size(64.dp))
                    Spacer(Modifier.height(10.dp))
                    ALText("Vault is empty", size = 18, weight = FontWeight.Bold)
                    ALText("Add photos, videos or documents to hide them.", size = 13, color = pal.sub, align = TextAlign.Center)
                }
            }
        } else {
            itemsIndexed(items, key = { _, x -> x.id }) { i, x -> VaultCard(x, i) { open = x } }
        }
    }
    val cur = open
    if (cur != null) {
        Dialog(onDismissRequest = { open = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            VaultViewer(cur) { open = null }
        }
    }
}

@Composable
private fun VaultCard(x: Vault.Item, idx: Int, onClick: () -> Unit) {
    val pal = LocalPal.current
    val shape = RoundedCornerShape(20.dp)
    val isImg = x.mime.startsWith("image/")
    val bmp by produceState<ImageBitmap?>(null, x.id) {
        if (isImg) value = withContext(Dispatchers.IO) { Vault.image(x, 4) }
    }
    var vis by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay((idx % 8) * 50L)
        vis = true
    }
    AnimatedVisibility(vis, enter = fadeIn(tween(350))) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(1f).bounceClick(onClick).clip(shape)
                .background(pal.card).border(1.dp, pal.border, shape)
        ) {
            val b = bmp
            if (b != null) {
                Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                Icon(Icons.Rounded.Description, null, tint = pal.accent, modifier = Modifier.align(Alignment.Center).size(34.dp))
            }
            Box(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xAA000000))))
                    .padding(8.dp)
            ) { ALText(x.name, size = 11, color = Color.White, maxLines = 1) }
        }
    }
}

@Composable
private fun VaultViewer(x: Vault.Item, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val pal = LocalPal.current
    val scope = rememberCoroutineScope()
    var note by remember { mutableStateOf("") }
    val isImg = x.mime.startsWith("image/")
    val bmp by produceState<ImageBitmap?>(null, x.id) {
        if (isImg) value = withContext(Dispatchers.IO) { Vault.image(x, 2) }
    }
    val exp = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri ->
        if (uri != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) { Vault.export(ctx, x, uri) }
                note = if (ok) "Decrypted copy saved." else "Export failed."
            }
        }
    }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        val b = bmp
        if (b != null) {
            Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        } else {
            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Rounded.Description, null, tint = Color.White, modifier = Modifier.size(72.dp))
                Spacer(Modifier.height(8.dp))
                ALText(x.name, size = 16, color = Color.White, align = TextAlign.Center)
                ALText("${x.size / 1024} KB  -  ${x.mime}", size = 12, color = Color(0xAAFFFFFF))
            }
        }
        Box(
            Modifier.align(Alignment.TopEnd).systemBarsPadding().padding(16.dp).size(44.dp)
                .clip(CircleShape).background(Color(0x66000000)).bounceClick(onClose),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.Close, null, tint = Color.White) }
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().systemBarsPadding().padding(16.dp)
                .clip(RoundedCornerShape(22.dp)).background(Color(0x99000000)).padding(16.dp)
        ) {
            ALText(x.name, size = 15, weight = FontWeight.Bold, color = Color.White, maxLines = 1)
            if (note.isNotEmpty()) ALText(note, size = 12, color = Color(0xFF34D399))
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    Modifier.bounceClick { exp.launch(x.name) }.clip(RoundedCornerShape(14.dp))
                        .background(pal.accent).padding(horizontal = 16.dp, vertical = 10.dp)
                ) { ALText("Export", size = 13, weight = FontWeight.Bold, color = Color.White) }
                Box(
                    Modifier.bounceClick {
                        Vault.delete(ctx, x)
                        onClose()
                    }.clip(RoundedCornerShape(14.dp)).background(pal.bad).padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Delete, null, tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        ALText("Delete", size = 13, weight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
}
