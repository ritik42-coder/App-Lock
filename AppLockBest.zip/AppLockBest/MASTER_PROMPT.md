# MASTER PROMPT — "App Lock Best" (pure native Android)

You are a senior Android engineer and motion designer. Build **App Lock Best**, a premium, 100% native
Android app (Kotlin + Jetpack Compose + Material 3, minSdk 26, targetSdk 34). NO WebView, no hybrid code.
Deliver a complete Gradle project that builds with `gradle assembleDebug` and a GitHub Actions workflow
(`.github/workflows/build-apk.yml`) that builds the APK, uploads it as an artifact and publishes a Release.
The workflow must also auto-unzip a project ZIP if that is all that was uploaded to the repo root.

## Core engine
- Foreground service (specialUse) polls UsageStatsManager events to detect the foreground app.
- When a locked app opens, launch a full-screen LockActivity (needs Usage Access + Display over other apps).
- Re-lock modes: instantly, after 1 minute, after screen off. Boot receiver restarts the service.
- LockActivity: FLAG_SECURE, back = go Home, finishes itself if the user leaves it.
- The app itself is protected by the same lock (gate screen after 15 s in background).

## Lock methods
PIN (4/6 digits), pattern (3x3, custom canvas), fingerprint/face via BiometricPrompt, shuffled keypad,
haptics, hidden pattern path, 30 s brute-force cooldown after every 5 wrong tries. Credentials stored as salted SHA-256.

## Signature feature — Intruder Selfie
After N wrong attempts (default **2**, selectable 1-5) silently capture a front-camera photo with CameraX
(ImageCapture + hidden dummy Preview surface for reliability). Mirror + rotate correctly, downscale to 1280 px,
save to app-private storage with timestamp + targeted app in the filename, post an "Intruder caught" notification.
"Selfies" tab: animated staggered grid, full-screen viewer showing app name + time, delete. Works for the
app's own gate too.

## UI / design (two completely different designs, follow system light/dark)
- DARK: deep navy/violet space, neon violet + cyan glow, twinkling stars, glass cards.
- LIGHT: ivory/pastel aurora, floating soft bubbles, frosted white cards with soft coloured shadows.
- Live animated background on every screen; theme override (System / Light / Dark) in Settings.
- Animation everywhere: spring-bounce press on every control, animated toggles (lock/unlock thumb), animated
  bottom nav with expanding labels, directional slide+fade tab transitions, staggered list entrance, scroll-driven
  3D tilt/scale/fade on the app list (graphicsLayer rotationX), animated count-up stats, pulsing hero orb with
  rotating sweep arc, shake on wrong code, success check burst.

## Cinematic opening (must feel like a video)
~7 s Canvas animation: warp-speed starfield -> neon phone outline draws itself -> 12 app icons pop in ->
laser scan sweeps down and turns each icon into a locked icon -> phone zooms away -> giant padlock appears,
shackle lifts and SLAMS shut with screen shake, haptic, white flash and double shockwave rings ->
"APP LOCK BEST" letters fly in with glow -> tagline fades in. Skip button top-right.

## Lock-screen styles (selectable, live preview)
LIVE: Aurora Flow, Neon Grid (retro-wave), Hyperspace, Code Rain (matrix), Deep Ocean.
STATIC: Midnight (AMOLED), Sunset Glow, Frost Glass (adapts to light/dark).
Each lock screen: pulsing app-icon badge with the target app's real icon and name.

## Other
Search + filter app list, "Lock essentials" smart preset, permission centre with live status,
adaptive premium icon (shield + padlock, gradient) with monochrome layer, setup wizard, light dependency set
(no Room/Hilt/KSP to keep the build bullet-proof).

## Rules
Output the full source (every file, no placeholders). Pin versions: AGP 8.5.2, Kotlin 1.9.24, Compose BOM 2024.06.00,
CameraX 1.3.4, Gradle 8.7, JDK 17. Explain nothing until the code is complete, then list manual steps.
